﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine.UI;
using UnityEngine;

public class AgentStateText : MonoBehaviour
{
    public Text ID = null;
    public Text infoEnergy = null;
    public Text infoHP = null;

    // Start is called before the first frame update
    void Start()
    {

    }

    // Update is called once per frame
    void Update()
    {
        // show the agent ID
        ID.transform.position = transform.position + new Vector3(0, 3, 0);
        ID.fontSize = 1;
        ID.text = gameObject.GetComponent<AgentState>().ID;

        // show the update Energy value
        infoEnergy.transform.position = transform.position + new Vector3(0, 2, 0);
        infoEnergy.fontSize = 1;
        infoEnergy.text = "NRG: " + gameObject.GetComponent<AgentState>().agentEnergy.ToString("0.00");

        // show the update HP value
        infoHP.transform.position = transform.position + new Vector3(0, 1, 0);
        infoHP.fontSize = 1;
        infoHP.text = "HP: " + gameObject.GetComponent<AgentState>().agentHP.ToString("0.00");     
    }
}
