﻿using System.Collections;
using System.Collections.Generic;
using System.Text.RegularExpressions;
using UnityEngine;
using System;

public class AgentState : MonoBehaviour
{
    public string ID;
    public float agentEnergy;
    public float agentHP;
    public float agentRadius;
    public float agentSpeed;
    public float perStepEnergyCost;
    public float perTimeCommunicationCost;
    public float unitAttackingEnergyCost;
    public float agentEnergyCost;
    public float systemEnergyCost = 0;
    public float agentHPCost = 0;
    public float systemHPCost;
    public float unitHPCost;
    public float estimationMonsterEnergyLevel;
    public float estimationMonsterHPLevel;
    public float estimateUnitMonsterAttackingEnergyCost;
    public int numGroups;
    public int numAgents;
    public int activeNumAgents = 0;
    public Vector3 agentPos;
    public Vector3 safetyPos;
    public Vector3 goalPos;
    public Vector3 centralGoalPos;
    public Vector3 getherPos; // after avoiding the obstacls, gether to specific position
    public string level1Decision;
    public string level2Decision;
    public string level3Decision;
    private float sumAttackingEnergyCost = 0;

    // Start is called before the first frame update
    void Start()
    {
        ID = gameObject.name;
        agentRadius = 3f;
        agentSpeed = 10.0f;
        unitAttackingEnergyCost = 0.01f;
        unitHPCost = gameObject.GetComponentInChildren<ExplorerAttackingState>().unitHPCost;
        safetyPos = GetSafetyPos(ID);
        centralGoalPos = new Vector3(-10, 0, 200);
    }

    // Update is called once per frame
    void Update()
    {
        // update agents' number in agent's state
        numAgents = gameObject.GetComponent<CommunicationFramework>().CommunicationList.Count;
        // update active agents' number
        activeNumAgents = gameObject.GetComponent<Selection>().activeAgentsList.Count;
        // update agent's goalPos in agent's state
        goalPos = GetGoalPos(ID);
        // update agent's HP in agent's state
        agentHP = gameObject.GetComponentInChildren<ExplorerAttackingState>().currentHP;
        // update agent's per time communication cost
        if(agentPos == goalPos || agentHP < 10f)
        {
            perTimeCommunicationCost = 0;
        }
        else
        {
            perTimeCommunicationCost = 0.006f;
        }
        // calculate agent energy cost
        agentEnergyCost = perStepEnergyCost + perTimeCommunicationCost + gameObject.GetComponentInChildren<ExplorerAttackingEnergyCost>().attackingEnergyCost;
        // update agent's energy level
        agentEnergy = gameObject.GetComponent<Routing>().currentAgentEnergy - gameObject.GetComponentInChildren<ExplorerAttackingEnergyCost>().attackingEnergyCost - perTimeCommunicationCost;
        // update agent's HP cost
        if(agentHP > 0)
        {
            agentHPCost = 100f - agentHP;
        }
        else
        {
            agentHPCost = 100;
        }
        // level1Decision = "Patroling";
        level1Decision = gameObject.GetComponent<ImportDecisionLevel>().explorerLevel1Decision;

        if(level1Decision == "")
        {
            level2Decision = "Nearest";
        }
        else
        {
            level2Decision = gameObject.GetComponent<ImportDecisionLevel>().explorerLevel2Decision;
        }

        level3Decision = gameObject.GetComponent<ImportDecisionLevel>().explorerLevel3Decision;
        numGroups = GetNumGroups(level3Decision);

        GetSystemInfo();
    }

    private Vector3 GetSafetyPos(string ID)
    {
        float tmp = 0;
        Vector3 safetyPos = new Vector3();

        string tmps = Regex.Replace(ID, "[a-z]", "", RegexOptions.IgnoreCase);
        float.TryParse(tmps, out tmp);

        safetyPos = new Vector3(tmp * 5, 10f, -600f);

        return safetyPos;
    }

    private Vector3 GetGoalPos(string ID)
    {
        float tmp = 0;
        float taskRadius = 6 * agentRadius;
        float theta = 0;

        // set the initial point
        goalPos = centralGoalPos;

        string tmps = Regex.Replace(ID, "[a-z]", "", RegexOptions.IgnoreCase);
        float.TryParse(tmps, out tmp);

        if(numAgents != 0)
        {
            theta = Convert.ToSingle(Math.PI * 2 * tmp / numAgents);
            goalPos = goalPos + new Vector3(Convert.ToSingle(taskRadius * Math.Cos(theta)), 10, Convert.ToSingle(taskRadius * Math.Sin(theta)));
        }
        else
        {
            goalPos = new Vector3(10, 10, 10);
        }

        return goalPos;
    }

    private int GetNumGroups(string Level3Decision)
    {
        int tmp = 0;

        try
        {
            if(level3Decision == "One Group")
            {
                tmp = 1;
            }
            else if(level3Decision == "Two Groups")
            {
                tmp = 2;
            }
            else if(level3Decision == "Three Groups")
            {
                tmp = 3;
            }
        }
        catch (Exception e)
        {
            Console.WriteLine(e.Message);
        }

        return tmp;
    }

    private void GetSystemInfo()
    {
        systemHPCost = 0;

        if(gameObject.GetComponent<CommunicationFramework>().CommunicationList.Count != 0)
        {
            foreach(var item in gameObject.GetComponent<CommunicationFramework>().CommunicationList)
            {
                systemHPCost = systemHPCost + item.agentHPCost;
                systemEnergyCost = systemEnergyCost + item.agentEnergyCost;
            }
        }
    }

    public float GetEstimatedUnitMonsterAttackingEnergyCost(string id)
    {
        float tmp = 0;

        string tmps = Regex.Replace(id, "[a-z]", "", RegexOptions.IgnoreCase);
        float.TryParse(tmps, out tmp);

        // estimate the adversary's unit attacking energy cost from agents' per attack HP cost from the adversary
        // linear prediction model: y = a * x + b
        // estimateUnitMonsterAttackingEnergyCost = 0.08f * unitHPCost + 0.001f * Convert.ToSingle(tmp);

        // nonlinear prediction model: y = a * ln(bx) + c
        estimateUnitMonsterAttackingEnergyCost = -Convert.ToSingle(Math.Log(unitHPCost * Convert.ToSingle(tmp) * 0.1f)) * 0.02f;

        return estimateUnitMonsterAttackingEnergyCost;
    }

    public float GetEstimatedMonsterEnergyLevel(string id)
    {
        float tmp = 0;

        string tmps = Regex.Replace(id, "[a-z]", "", RegexOptions.IgnoreCase);
        float.TryParse(tmps, out tmp);

        // estimate the adversary's energy level from the average of system' HP cost from the adversary
        // linear prediction model: y = a * x + b
        // estimationMonsterEnergyLevel = 100 - 0.03f * systemHPCost * Convert.ToSingle(tmp) / gameObject.GetComponent<CommunicationFramework>().CommunicationList.Count;

        // nonlinear prediction model: y = a * ln(bx) + c
        if(systemHPCost == 0)
        {
            estimationMonsterEnergyLevel = 100;
        }
        else
        {
            estimationMonsterEnergyLevel = 100 - Convert.ToSingle(Math.Log(systemHPCost) * Convert.ToSingle(tmp)) * 0.1f;
        }

        return estimationMonsterEnergyLevel;
    }

    public float GetEstimationMonsterHPLevel(string id)
    {
        float tmp = 0;

        string tmps = Regex.Replace(id, "[a-z]", "", RegexOptions.IgnoreCase);
        float.TryParse(tmps, out tmp);

        // estimate the adversary's energy level from system's current attacking energy cost
        // linear prediction model: y = a * x + b
        foreach(var item in gameObject.GetComponent<CommunicationFramework>().CommunicationList)
        {
            sumAttackingEnergyCost = sumAttackingEnergyCost + item.GetComponentInChildren<ExplorerAttackingEnergyCost>().attackingEnergyCost;
        }

        estimationMonsterHPLevel = 100 - sumAttackingEnergyCost * Convert.ToSingle(tmp) / gameObject.GetComponent<CommunicationFramework>().CommunicationList.Count;


        // nonlinear prediction model: y = a * ln(bx) + c


        return estimationMonsterHPLevel;
    }
}