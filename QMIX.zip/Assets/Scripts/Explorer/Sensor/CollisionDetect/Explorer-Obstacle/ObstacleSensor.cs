﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ObstacleSensor : MonoBehaviour
{
    public List<Collider> obstacles = new List<Collider>();
    public List<ObstacleState> obstaclesInfo;
    public List<ExitState> exitInfo;
    private ObstacleState obstacleState;
    private ExitState exitState;

    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    private void OnTriggerEnter(Collider obstacle)
    {
        obstacleState = obstacle.GetComponent<ObstacleState>();
        exitState = obstacle.GetComponent<ExitState>();

        // update entire obstacles' list information
        if(obstacle.tag == "Rock")
        {
            obstacles.Add(obstacle);
            obstaclesInfo.Add(obstacleState);
        }

        // update exit list information
        if(obstacle.tag == "Exit")
        {
            exitInfo.Add(exitState);
        }
    }

    private void OnTriggerExit(Collider obstacle)
    {
        obstacleState = obstacle.GetComponent<ObstacleState>();
        exitState = obstacle.GetComponent<ExitState>();

        if(obstacle.tag == "Rock")
        {
            obstacles.Remove(obstacle);
            obstaclesInfo.Remove(obstacleState);
        }

        // when explorer exit the obstacle, gether to specific position
        if(obstacle.tag == "Exit")
        {
            exitInfo.Remove(exitState);
        }
    }
}
