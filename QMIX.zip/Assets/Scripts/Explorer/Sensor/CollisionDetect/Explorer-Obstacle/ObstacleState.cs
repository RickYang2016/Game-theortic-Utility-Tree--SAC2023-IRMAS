﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ObstacleState : MonoBehaviour
{
    public string ID;

    // Start is called before the first frame update
    void Start()
    {
        ID = gameObject.name;
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
