﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PerceptionSensor : MonoBehaviour
{
    public List<Collider> agents = new List<Collider>();
    public List<PerceptionState> agentsInfo;
    private PerceptionState agentState;

    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    private void OnTriggerEnter(Collider agent)
    {
        agentState = agent.GetComponent<PerceptionState>();

        // update agent's state and entire agents' list information
        if(agent.tag == "ExplorerBody")
        {
            agents.Add(agent);
            agentsInfo.Add(agentState);
        }
    }

    private void OnTriggerExit(Collider agent)
    {
        agentState = agent.GetComponent<PerceptionState>();

        if(agent.tag == "ExplorerBody")
        {
            agents.Remove(agent);
            agentsInfo.Remove(agentState);
        }
    }
}
