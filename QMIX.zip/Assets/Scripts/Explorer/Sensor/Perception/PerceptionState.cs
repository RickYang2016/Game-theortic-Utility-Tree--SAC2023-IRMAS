﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PerceptionState : MonoBehaviour
{
    public string ID;
    public float agentEnergy;
    public float agentHP;
    public float agentRadius;
    public float unitAttackingEnergyCost;
    public float agentSpeed;
    public Vector3 agentPos;

    // Start is called before the first frame update
    void Start()
    {
        ID = gameObject.GetComponentInParent<AgentState>().name;
        agentRadius = gameObject.GetComponentInParent<AgentState>().agentRadius;
    }

    // Update is called once per frame
    void Update()
    {
        agentEnergy = gameObject.GetComponentInParent<AgentState>().agentEnergy;
        agentHP = gameObject.GetComponentInParent<AgentState>().agentHP;
        agentPos = gameObject.GetComponentInParent<AgentState>().agentPos;
        unitAttackingEnergyCost = gameObject.GetComponentInParent<AgentState>().unitAttackingEnergyCost;
        agentSpeed = gameObject.GetComponentInParent<AgentState>().agentSpeed;
    }
}
