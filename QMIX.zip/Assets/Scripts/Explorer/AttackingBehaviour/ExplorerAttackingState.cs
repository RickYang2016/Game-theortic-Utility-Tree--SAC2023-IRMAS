﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ExplorerAttackingState : MonoBehaviour
{
    public float currentHP = 100f;
    public float unitHPCost = 0.15f;

    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    private void OnTriggerStay(Collider agent)
    {
        if(agent.tag == "MonsterAttackingRange")
        {
            currentHP = currentHP - unitHPCost;
        }
    }
}
