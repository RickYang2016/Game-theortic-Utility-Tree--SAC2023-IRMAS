﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System.Diagnostics;
using System.IO;
using System;

public class CommunicationFramework : MonoBehaviour
{
    public List<perceptiveMonsterState> perceptionList;
    public List<ObstacleState> perceptionObstacles;
    public List<ExitState> perceptionExit;
    public List<AgentState> CommunicationList;
    public List<perceptiveMonsterState> MonstersList;
    public List<PerceptionState> observationActiveAgentsList;
    public List<ObstacleState> ObstaclesList;
    public List<ExitState> ExitList;

    // Start is called before the first frame update
    void Start()
    {

    }
    
    void Update()
    {   // percept monsters
        perceptionList = gameObject.GetComponentInChildren<MonsterPerception>().agentsInfo;
        // percept obstacles
        perceptionObstacles = gameObject.GetComponentInChildren<ObstacleSensor>().obstaclesInfo;
        // percept exit
        perceptionExit = gameObject.GetComponentInChildren<ObstacleSensor>().exitInfo;
        // get all connected explorers
        GetUnionList(gameObject.GetComponent<AgentState>());
        // // get all percepted monsters
        // GetMonstersList(CommunicationList);
        // get all percepted obstacles
        GetObstaclesList(CommunicationList);
        // get the exit
        GetExitList(CommunicationList);

        // only get the monsters from individual agent's perception
        GetIndividualMonstersList(perceptionList);
        // only get the explorers from individual agent's perception
        GetIndividualExploersList(gameObject.GetComponentInChildren<PerceptionState>());
    }

    private void GetUnionList(AgentState currentAgent)
    {
        Queue<AgentState> tmpQueue = new Queue<AgentState>();
        CommunicationList = new List<AgentState>();

        tmpQueue.Enqueue(currentAgent);

        while(tmpQueue.Count > 0)
        {
            AgentState agent = tmpQueue.Dequeue();

            foreach(var item in agent.GetComponent<AgentBehaviour>().agentsInfo)
            {                
                if(!CommunicationList.Contains(item))
                {
                    CommunicationList.Add(item);
                    tmpQueue.Enqueue(item);
                }
            }
        }
    }

    private void GetMonstersList(List<AgentState> currentComList)
    {
        MonstersList = new List<perceptiveMonsterState>();

        foreach(var item in currentComList)
        {
            foreach(var agent in item.GetComponent<CommunicationFramework>().perceptionList)
            {
                if(!MonstersList.Contains(agent))
                {
                    MonstersList.Add(agent);
                }
            }
        }
    }

    // for QMIX experoments perceive exploers' number
    private void GetIndividualExploersList(PerceptionState currentAgent)
    {
        observationActiveAgentsList = new List<PerceptionState>();

        if(!observationActiveAgentsList.Contains(currentAgent))
        {
            observationActiveAgentsList.Add(currentAgent);
        }

        foreach(var item in gameObject.GetComponentInChildren<PerceptionSensor>().agentsInfo)
        {                
            if(!observationActiveAgentsList.Contains(item) && item.agentHP >= 10)
            {
                observationActiveAgentsList.Add(item);
            }
        }
    }    

    // for QMIX experiments perceive monsters' number
    private void GetIndividualMonstersList(List<perceptiveMonsterState> perceptionList)
    {
        MonstersList = new List<perceptiveMonsterState>();

        foreach(var agent in perceptionList)
        {
            if(!MonstersList.Contains(agent))
            {
                MonstersList.Add(agent);
            }
        }

    }


    private void GetObstaclesList(List<AgentState> currentComList)
    {
        ObstaclesList = new List<ObstacleState>();

        foreach(var item in currentComList)
        {
            foreach(var obstacle in item.GetComponent<CommunicationFramework>().perceptionObstacles)
            {
                if(!ObstaclesList.Contains(obstacle))
                {
                    ObstaclesList.Add(obstacle);
                }
            }
        }
    }

    private void GetExitList(List<AgentState> currentComList)
    {
        ExitList = new List<ExitState>();

        foreach(var item in currentComList)
        {
            foreach(var exit in item.GetComponent<CommunicationFramework>().perceptionExit)
            {
                if(!ExitList.Contains(exit))
                {
                    ExitList.Add(exit);
                }
            }
        }
    }
}
