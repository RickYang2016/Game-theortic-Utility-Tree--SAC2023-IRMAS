﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MonsterAttackingState : MonoBehaviour
{
    public float currentHP = 100f;
    public float unitHPCost = 0.05f;

    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    private void OnTriggerStay(Collider agent)
    {
        if(agent.tag == "ExplorerAttackingRange")
        {
            currentHP = currentHP - unitHPCost;
        }
    }

    private void OnTriggerEnter(Collider agent)
    {
        if(agent.tag == "Rock")
        {
            gameObject.GetComponentInParent<Rigidbody>().velocity = Vector3.zero;
        }
    }
}
