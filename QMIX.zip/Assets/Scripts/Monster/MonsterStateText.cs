﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine.UI;
using UnityEngine;

public class MonsterStateText : MonoBehaviour
{
    
    public Text MonsterID = null;
    public Text MonsterNRG = null;
    public Text MonsterHP = null;

    // Start is called before the first frame update
    void Start()
    {

    }

    // Update is called once per frame
    void Update()
    {
        // show the agent ID
        MonsterID.transform.position = transform.position + new Vector3(0, 6, 0);
        MonsterID.fontSize = 1;
        MonsterID.text = gameObject.GetComponent<MonsterState>().ID;

        // show the update Energy value
        MonsterNRG.transform.position = transform.position + new Vector3(0, 5, 0);
        MonsterNRG.fontSize = 1;
        MonsterNRG.text = "NRG: " + gameObject.GetComponent<MonsterState>().agentEnergy.ToString("0.00");

        // show the update HP value
        MonsterHP.transform.position = transform.position + new Vector3(0, 4, 0);
        MonsterHP.fontSize = 1;
        MonsterHP.text = "HP: " + gameObject.GetComponent<MonsterState>().agentHP.ToString("0.00"); 
    }
}
