﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System;

public class CameraFlow : MonoBehaviour
{
    public Transform target;
    private Vector3 offset = new Vector3(10,10,10);

    // Start is called before the first frame update
    void Start()
    {

    }

    // Update is called once per frame
    void Update()
    {
        try
        {
            target.position = gameObject.GetComponentInParent<Formation>().GetCentralPoint();
            transform.LookAt(offset + target.position);
        }
        catch (Exception e)
        {
            Console.WriteLine(e.Message);
            return;
        }
    }
}
