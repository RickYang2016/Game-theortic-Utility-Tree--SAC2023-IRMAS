import matplotlib.pyplot as plt
from dateutil.parser import parse
import time
import numpy as np
import os

fig3, axes3 = plt.subplots(1,3,  gridspec_kw = {'width_ratios':[1, 1, 1]})

twenty_five_vs_twenty_five = [[90.19, 91.75, 90.73 ,95.32, 94.09, 87.18, 78.51, 75.68, 92.81, 90.94], \
							  [94.59, 87.48, 87.70, 81.42, 90.52, 96.96, 93.25, 90.09, 92.27, 95.18], \
		  					  [81.39, 58.49, 41.59, 91.70, 82.18, 69.06, 47.03, 78.42, 64.33, 94.62]]

twenty_vs_thirty = [[99.37, 96.26, 92.48, 95.85, 99.26, 97.86, 98.03, 96.00, 95.17, 95.79], \
		  			[94.40, 98.33, 89.83, 99.25, 99.92, 95.61, 98.22, 96.85, 98.40, 96.34], \
		  			[93.70, 93.88, 65.48, 94.16, 99.40, 95.16, 97.67, 97.43, 94.83, 95.73]]

thirty_vs_twenty = [[81.46, 82.43, 80.26, 76.87, 76.54, 79.35, 90.16, 84.90, 85.24, 81.61], \
		  			[74.76, 87.88, 86.53, 79.99, 84.98, 87.10, 77.75, 75.11, 86.44, 80.26], \
		  			[86.77, 79.42, 49.59, 84.26, 82.10, 90.16, 63.46, 72.48, 64.50, 74.31]]

# 25 vs 25

labels5 = ['$QMIX_{GUT}$', '$QMIX$', '$GUT$']

bplot5 = axes3[0].boxplot(twenty_five_vs_twenty_five, \
					patch_artist=True, \
					labels=labels5, \
					widths=0.5, \
					boxprops = {'color':'black','facecolor':'#9999ff'}, \
					flierprops = {'marker':'o','markerfacecolor':'white','color':'black'}, \
					whiskerprops = {'color':'black', 'linestyle':'-'})

for i in range(len(bplot5['boxes'])):
	if i == 0:
	    # change outline color
	    bplot5['boxes'][i].set(color='black', linewidth=2)
	    # change fill color
	    bplot5['boxes'][i].set(facecolor = 'green')
	    # change hatch
	    bplot5['boxes'][i].set(hatch = '/')

	if i == 1:
	    # change outline color
	    bplot5['boxes'][i].set(color='black', linewidth=2)
	    # change fill color
	    bplot5['boxes'][i].set(facecolor = 'green')
	    # change hatch
	    bplot5['boxes'][i].set(hatch = 'o')

	if i == 2:
	    # change outline color
	    bplot5['boxes'][i].set(color='black', linewidth=2)
	    # change fill color
	    bplot5['boxes'][i].set(facecolor = 'green')
	    # change hatch
	    bplot5['boxes'][i].set(hatch = 'x')

colors5 = ['lightblue', 'lightgreen', 'pink']
for patch, color in zip(bplot5['boxes'], colors5):
    patch.set_facecolor(color)

axes3[0].tick_params(top='off', right='off')
axes3[0].set_ylabel('Explorer Average HP Cost', fontsize=15)
axes3[0].set_xlabel('25e vs 25m', fontsize=15)
axes3[0].tick_params('x', labelsize=9)

# 20 vs 30
labels6 = ['$QMIX_{GUT}$', '$QMIX$', '$GUT$']

bplot6 = axes3[1].boxplot(twenty_vs_thirty, \
					patch_artist=True, \
					labels=labels6, \
					widths = 0.5,\
					boxprops = {'color':'black','facecolor':'#9999ff'}, \
					flierprops = {'marker':'o','markerfacecolor':'white','color':'black'}, \
					whiskerprops = {'color':'black', 'linestyle':'-'})

for i in range(len(bplot6['boxes'])):
	if i == 0:
	    # change outline color
	    bplot6['boxes'][i].set(color='black', linewidth=2)
	    # change fill color
	    bplot6['boxes'][i].set(facecolor = 'green')
	    # change hatch
	    bplot6['boxes'][i].set(hatch = '/')

	if i == 1:
	    # change outline color
	    bplot6['boxes'][i].set(color='black', linewidth=2)
	    # change fill color
	    bplot6['boxes'][i].set(facecolor = 'green')
	    # change hatch
	    bplot6['boxes'][i].set(hatch = 'o')

	if i == 2:
	    # change outline color
	    bplot6['boxes'][i].set(color='black', linewidth=2)
	    # change fill color
	    bplot6['boxes'][i].set(facecolor = 'green')
	    # change hatch
	    bplot6['boxes'][i].set(hatch = 'x')

colors6 = ['lightblue', 'lightgreen', 'pink']
for patch, color in zip(bplot6['boxes'], colors6):
    patch.set_facecolor(color)

axes3[1].tick_params(top='off', right='off')
axes3[1].set_xlabel('20e vs 30m', fontsize=15)
axes3[1].tick_params('x', labelsize=9)

# 30 vs 20
labels7 = ['$QMIX_{GUT}$', '$QMIX$', '$GUT$']

bplot7 = axes3[2].boxplot(thirty_vs_twenty, \
					patch_artist=True, \
					labels=labels6, \
					widths = 0.5,\
					boxprops = {'color':'black','facecolor':'#9999ff'}, \
					flierprops = {'marker':'o','markerfacecolor':'white','color':'black'}, \
					whiskerprops = {'color':'black', 'linestyle':'-'})

for i in range(len(bplot7['boxes'])):
	if i == 0:
	    # change outline color
	    bplot7['boxes'][i].set(color='black', linewidth=2)
	    # change fill color
	    bplot7['boxes'][i].set(facecolor = 'green')
	    # change hatch
	    bplot7['boxes'][i].set(hatch = '/')

	if i == 1:
	    # change outline color
	    bplot7['boxes'][i].set(color='black', linewidth=2)
	    # change fill color
	    bplot7['boxes'][i].set(facecolor = 'green')
	    # change hatch
	    bplot7['boxes'][i].set(hatch = 'o')

	if i == 2:
	    # change outline color
	    bplot7['boxes'][i].set(color='black', linewidth=2)
	    # change fill color
	    bplot7['boxes'][i].set(facecolor = 'green')
	    # change hatch
	    bplot7['boxes'][i].set(hatch = 'x')

colors7 = ['lightblue', 'lightgreen', 'pink']
for patch, color in zip(bplot7['boxes'], colors7):
    patch.set_facecolor(color)

axes3[2].tick_params(top='off', right='off')
axes3[2].set_xlabel('30e vs 20m', fontsize=15)
axes3[2].tick_params('x', labelsize=9)

plt.subplots_adjust(bottom=None, wspace=0.3)

plt.show()