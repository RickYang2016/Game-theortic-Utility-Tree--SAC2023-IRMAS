import matplotlib.pyplot as plt
from dateutil.parser import parse
import time
import math
import numpy as np
import os
import itertools as it
from datetime import datetime
from sklearn.linear_model import LinearRegression


complete_info = "/home/herobot/Documents/research/published_papers/NIPS2020/data/parameter_estimation/com/4"

incomplete_info_linear = "/home/herobot/Documents/research/published_papers/NIPS2020/data/parameter_estimation/incom_linear/4"

incomplete_info_Polynomial_Regression = "/home/herobot/Documents/research/published_papers/NIPS2020/data/parameter_estimation/Polynomial_Regression/4"


files14 = os.listdir(complete_info)

files24 = os.listdir(incomplete_info_linear)

files54 = os.listdir(incomplete_info_Polynomial_Regression)


# complete info 
# all agents
for file14 in files14:
	if not os.path.isdir(file14):
		ratio14, kill_per_monster_HP_cost14, kill_per_monster_number_of_explorers_losing14, complete_task_each_explorer_energy_cost14, complete_task_each_explorer_HP_cost14 = [],[],[],[],[]
		f14 = open(complete_info + "/" + file14, "r");

		for line in f14:
			value14 = [str(s) for s in line.split()]
			ratio14.append(math.log(float(value14[0]), 10))
			kill_per_monster_HP_cost14.append(float(value14[1]))
			kill_per_monster_number_of_explorers_losing14.append(float(value14[2]))
			complete_task_each_explorer_energy_cost14.append(float(value14[3]))
			complete_task_each_explorer_HP_cost14.append(float(value14[4]))


# incomplete info
# Linear Regression all agents
for file24 in files24:
	if not os.path.isdir(file24):
		ratio24, kill_per_monster_HP_cost24, kill_per_monster_number_of_explorers_losing24, complete_task_each_explorer_energy_cost24, complete_task_each_explorer_HP_cost24 = [],[],[],[],[]
		f24 = open(incomplete_info_linear + "/" + file24, "r");

		for line in f24:
			value24 = [str(s) for s in line.split()]
			ratio24.append(math.log(float(value24[0]), 10))
			kill_per_monster_HP_cost24.append(float(value24[1]))
			kill_per_monster_number_of_explorers_losing24.append(float(value24[2]))
			complete_task_each_explorer_energy_cost24.append(float(value24[3]))
			complete_task_each_explorer_HP_cost24.append(float(value24[4]))

# incomplete info
# Polynomial Regression all agents
for file54 in files54:
	if not os.path.isdir(file54):
		ratio54, kill_per_monster_HP_cost54, kill_per_monster_number_of_explorers_losing54, complete_task_each_explorer_energy_cost54, complete_task_each_explorer_HP_cost54 = [],[],[],[],[]
		f54 = open(incomplete_info_Polynomial_Regression + "/" + file54, "r");

		for line in f54:
			value54 = [str(s) for s in line.split()]
			ratio54.append(math.log(float(value54[0]), 10))
			kill_per_monster_HP_cost54.append(float(value54[1]))
			kill_per_monster_number_of_explorers_losing54.append(float(value54[2]))
			complete_task_each_explorer_energy_cost54.append(float(value54[3]))
			complete_task_each_explorer_HP_cost54.append(float(value54[4]))

# ==============================================================================================================================
# all agents
# ==============================================================================================================================
# # Com
# X_train_1 = np.array(ratio14).reshape(-1, 1)
# Y_train_1 = np.array(kill_per_monster_HP_cost14).reshape(-1, 1)

# model = LinearRegression()
# model.fit(X_train_1, Y_train_1)
# Y_train_pred_1 = model.predict(X_train_1)


# # Incom L
# X_train_2 = np.array(ratio24).reshape(-1, 1)
# Y_train_2 = np.array(kill_per_monster_HP_cost24).reshape(-1, 1)

# model = LinearRegression()
# model.fit(X_train_2, Y_train_2)
# Y_train_pred_2 = model.predict(X_train_2)

# # Incom NonL
# X_train_3 = np.array(ratio54).reshape(-1, 1)
# Y_train_3 = np.array(kill_per_monster_HP_cost54).reshape(-1, 1)

# model = LinearRegression()
# model.fit(X_train_3, Y_train_3)
# Y_train_pred_3 = model.predict(X_train_3)


# plt.figure()
# # plt.title('(i) SC.3 - Fixed Agents (E+M=50)', fontsize = 15)
# plt.scatter(ratio14, kill_per_monster_HP_cost14, marker = 'p')
# plt.scatter(ratio24, kill_per_monster_HP_cost24, marker = '^')
# plt.scatter(ratio54, kill_per_monster_HP_cost54, marker = '*')

# plt.plot(X_train_1, Y_train_pred_1, color = 'steelblue', label = 'best line')
# plt.plot(X_train_2, Y_train_pred_2, color = 'orange', label = 'best line')
# plt.plot(X_train_3, Y_train_pred_3, color = 'green', label = 'best line')

# plt.xlabel('log(Ratio(M/E))', fontsize = 15)
# plt.ylabel('Exp. HP Cost Per Kill Monster', fontsize = 15)
# plt.legend(['Coop. Full Info. Trend','Coop. Linear Pred. Trend', 'Coop. Polynomial Pred. Trend', 'Coop. Full Info.','Coop. Linear Pred.', 'Coop. Polynomial Pred.'])
# plt.show()

# ============================================================================================================================
# # Com
# X_train_1 = np.array(ratio14).reshape(-1, 1)
# Y_train_1 = np.array(kill_per_monster_number_of_explorers_losing14).reshape(-1, 1)

# model = LinearRegression()
# model.fit(X_train_1, Y_train_1)
# Y_train_pred_1 = model.predict(X_train_1)


# # Incom L
# X_train_2 = np.array(ratio24).reshape(-1, 1)
# Y_train_2 = np.array(kill_per_monster_number_of_explorers_losing24).reshape(-1, 1)

# model = LinearRegression()
# model.fit(X_train_2, Y_train_2)
# Y_train_pred_2 = model.predict(X_train_2)

# # Incom NonL
# X_train_3 = np.array(ratio54).reshape(-1, 1)
# Y_train_3 = np.array(kill_per_monster_number_of_explorers_losing54).reshape(-1, 1)

# model = LinearRegression()
# model.fit(X_train_3, Y_train_3)
# Y_train_pred_3 = model.predict(X_train_3)


# plt.figure()
# # plt.title('(j) SC.3 - Fixed Agents (E+M=50)', fontsize = 15)
# plt.scatter(ratio14, kill_per_monster_number_of_explorers_losing14, marker = 'p')
# plt.scatter(ratio24, kill_per_monster_number_of_explorers_losing24, marker = '^')
# plt.scatter(ratio54, kill_per_monster_number_of_explorers_losing54, marker = '*')

# plt.plot(X_train_1, Y_train_pred_1, color = 'steelblue', label = 'best line')
# plt.plot(X_train_2, Y_train_pred_2, color = 'orange', label = 'best line')
# plt.plot(X_train_3, Y_train_pred_3, color = 'green', label = 'best line')

# plt.xlabel('log(Ratio(M/E))', fontsize = 15)
# plt.ylabel('Exp. Lost Per Kill Monster', fontsize = 15)
# plt.legend(['Coop. Full Info. Trend','Coop. Linear Pred. Trend', 'Coop. Polynomial Pred. Trend', 'Coop. Full Info.','Coop. Linear Pred.', 'Coop. Polynomial Pred.'])
# plt.show()

# =====================================================================================================================================
# # Com
# X_train_1 = np.array(ratio14).reshape(-1, 1)
# Y_train_1 = np.array(complete_task_each_explorer_energy_cost14).reshape(-1, 1)

# model = LinearRegression()
# model.fit(X_train_1, Y_train_1)
# Y_train_pred_1 = model.predict(X_train_1)


# # Incom L
# X_train_2 = np.array(ratio24).reshape(-1, 1)
# Y_train_2 = np.array(complete_task_each_explorer_energy_cost24).reshape(-1, 1)

# model = LinearRegression()
# model.fit(X_train_2, Y_train_2)
# Y_train_pred_2 = model.predict(X_train_2)

# # Incom NonL
# X_train_3 = np.array(ratio54).reshape(-1, 1)
# Y_train_3 = np.array(complete_task_each_explorer_energy_cost54).reshape(-1, 1)

# model = LinearRegression()
# model.fit(X_train_3, Y_train_3)
# Y_train_pred_3 = model.predict(X_train_3)


# plt.figure()
# # plt.title('(l) SC.3 - Fixed Agents (E+M=50)', fontsize = 15)
# plt.scatter(ratio14, complete_task_each_explorer_energy_cost14, marker = 'p')
# plt.scatter(ratio24, complete_task_each_explorer_energy_cost24, marker = '^')
# plt.scatter(ratio54, complete_task_each_explorer_energy_cost54, marker = '*')

# plt.plot(X_train_1, Y_train_pred_1, color = 'steelblue', label = 'best line')
# plt.plot(X_train_2, Y_train_pred_2, color = 'orange', label = 'best line')
# plt.plot(X_train_3, Y_train_pred_3, color = 'green', label = 'best line')

# plt.xlabel('log(Ratio(M/E))', fontsize = 15)
# plt.ylabel('Exp. Average Energy Cost', fontsize = 15)
# plt.legend(['Coop. Full Info. Trend','Coop. Linear Pred. Trend', 'Coop. Polynomial Pred. Trend', 'Coop. Full Info.','Coop. Linear Pred.', 'Coop. Polynomial Pred.'], loc='right', bbox_to_anchor=(1, 0.7))
# plt.show()

# ================================================================================================================
# Com
X_train_1 = np.array(ratio14).reshape(-1, 1)
Y_train_1 = np.array(complete_task_each_explorer_HP_cost14).reshape(-1, 1)

model = LinearRegression()
model.fit(X_train_1, Y_train_1)
Y_train_pred_1 = model.predict(X_train_1)


# Incom L
X_train_2 = np.array(ratio24).reshape(-1, 1)
Y_train_2 = np.array(complete_task_each_explorer_HP_cost24).reshape(-1, 1)

model = LinearRegression()
model.fit(X_train_2, Y_train_2)
Y_train_pred_2 = model.predict(X_train_2)

# Polynomial Regression
X_train_3 = np.array(ratio54).reshape(-1, 1)
Y_train_3 = np.array(complete_task_each_explorer_HP_cost54).reshape(-1, 1)

model = LinearRegression()
model.fit(X_train_3, Y_train_3)
Y_train_pred_3 = model.predict(X_train_3)


plt.figure()
# plt.title('(k) SC.3 - All Agents', fontsize = 15)
plt.scatter(ratio14, complete_task_each_explorer_HP_cost14, marker = 'p')
plt.scatter(ratio24, complete_task_each_explorer_HP_cost24, marker = '^')
plt.scatter(ratio54, complete_task_each_explorer_HP_cost54, marker = '*')

plt.plot(X_train_1, Y_train_pred_1, color = 'steelblue')
plt.plot(X_train_2, Y_train_pred_2, color = 'orange')
plt.plot(X_train_3, Y_train_pred_3, color = 'green')

plt.xlabel('lg(Ratio(M/E))', fontsize = 15)
plt.ylabel('Exp. Average HP Cost', fontsize = 15)
plt.legend(['Coop. Full Info. Trend','Coop. Linear Pred. Trend', 'Coop. Polynomial Pred. Trend', 'Coop. Full Info.','Coop. Linear Pred.', 'Coop. Polynomial Pred.'])
plt.show()
