import matplotlib.pyplot as plt
from dateutil.parser import parse
import time
import numpy as np
import os

fig3, axes3 = plt.subplots(1,3,  gridspec_kw = {'width_ratios':[1, 1, 1]})
fig3.suptitle('25e vs 25m', fontsize=16)

com = [[17, 16, 3, 23, 20, 11, 2, 15, 8, 23], \
	   [16, 23, 21, 23, 23, 20, 17, 22, 17, 23]]

incom_linear = [[26, 26, 23, 26, 26, 28, 26, 26, 26, 21], \
		  	    [33, 36, 33, 36, 36, 33, 26, 29, 26, 33]]

incom_ploy = [[21, 31, 29, 29, 30, 30, 29, 28, 31, 29], \
		  	  [42, 42, 38, 42, 35, 38, 30, 38, 42, 38]]

# com

labels5 = ['$Int.$', '$Int. + Unint.$']

bplot5 = axes3[0].boxplot(com, \
					patch_artist=True, \
					labels=labels5, \
					widths=0.5, \
					boxprops = {'color':'black','facecolor':'#9999ff'}, \
					flierprops = {'marker':'o','markerfacecolor':'white','color':'black'}, \
					whiskerprops = {'color':'black', 'linestyle':'-'})

for i in range(len(bplot5['boxes'])):
	if i == 0:
	    # change outline color
	    bplot5['boxes'][i].set(color='black', linewidth=2)
	    # change fill color
	    bplot5['boxes'][i].set(facecolor = 'green')
	    # change hatch
	    bplot5['boxes'][i].set(hatch = 'x')

	if i == 1:
	    # change outline color
	    bplot5['boxes'][i].set(color='black', linewidth=2)
	    # change fill color
	    bplot5['boxes'][i].set(facecolor = 'green')
	    # change hatch
	    bplot5['boxes'][i].set(hatch = '.')

	# if i == 2:
	#     # change outline color
	#     bplot5['boxes'][i].set(color='black', linewidth=2)
	#     # change fill color
	#     bplot5['boxes'][i].set(facecolor = 'green')
	#     # change hatch
	#     bplot5['boxes'][i].set(hatch = 'x')

colors5 = ['palegreen', 'cyan']
for patch, color in zip(bplot5['boxes'], colors5):
    patch.set_facecolor(color)

axes3[0].tick_params(top='off', right='off')
axes3[0].set_ylabel('Explorer Average Lost Winning A Round', fontsize=15)
axes3[0].set_xlabel('Com.', fontsize=15)
axes3[0].tick_params('x', labelsize=9)

# incom_linear

labels6 = ['$Int.$', '$Int. + Unint.$']

bplot6 = axes3[1].boxplot(incom_linear, \
					patch_artist=True, \
					labels=labels6, \
					widths = 0.5,\
					boxprops = {'color':'black','facecolor':'#9999ff'}, \
					flierprops = {'marker':'o','markerfacecolor':'white','color':'black'}, \
					whiskerprops = {'color':'black', 'linestyle':'-'})

for i in range(len(bplot6['boxes'])):
	if i == 0:
	    # change outline color
	    bplot6['boxes'][i].set(color='black', linewidth=2)
	    # change fill color
	    bplot6['boxes'][i].set(facecolor = 'green')
	    # change hatch
	    bplot6['boxes'][i].set(hatch = 'x')

	if i == 1:
	    # change outline color
	    bplot6['boxes'][i].set(color='black', linewidth=2)
	    # change fill color
	    bplot6['boxes'][i].set(facecolor = 'green')
	    # change hatch
	    bplot6['boxes'][i].set(hatch = '.')

	# if i == 2:
	#     # change outline color
	#     bplot6['boxes'][i].set(color='black', linewidth=2)
	#     # change fill color
	#     bplot6['boxes'][i].set(facecolor = 'green')
	#     # change hatch
	#     bplot6['boxes'][i].set(hatch = 'x')

colors6 = ['palegreen', 'cyan']
for patch, color in zip(bplot6['boxes'], colors6):
    patch.set_facecolor(color)

axes3[1].tick_params(top='off', right='off')
axes3[1].set_xlabel('Incom. Linear', fontsize=15)
axes3[1].tick_params('x', labelsize=9)
# axes3[1].set_title('25e vs 25m', fontsize=20)

# incom_ploy

labels7 = ['$Int.$', '$Int. + Unint.$']

bplot7 = axes3[2].boxplot(incom_ploy, \
					patch_artist=True, \
					labels=labels6, \
					widths = 0.5,\
					boxprops = {'color':'black','facecolor':'#9999ff'}, \
					flierprops = {'marker':'o','markerfacecolor':'white','color':'black'}, \
					whiskerprops = {'color':'black', 'linestyle':'-'})

for i in range(len(bplot7['boxes'])):
	if i == 0:
	    # change outline color
	    bplot7['boxes'][i].set(color='black', linewidth=2)
	    # change fill color
	    bplot7['boxes'][i].set(facecolor = 'green')
	    # change hatch
	    bplot7['boxes'][i].set(hatch = 'x')

	if i == 1:
	    # change outline color
	    bplot7['boxes'][i].set(color='black', linewidth=2)
	    # change fill color
	    bplot7['boxes'][i].set(facecolor = 'green')
	    # change hatch
	    bplot7['boxes'][i].set(hatch = '.')

	# if i == 2:
	#     # change outline color
	#     bplot7['boxes'][i].set(color='black', linewidth=2)
	#     # change fill color
	#     bplot7['boxes'][i].set(facecolor = 'green')
	#     # change hatch
	#     bplot7['boxes'][i].set(hatch = 'x')

colors7 = ['palegreen', 'cyan']
for patch, color in zip(bplot7['boxes'], colors7):
    patch.set_facecolor(color)

axes3[2].tick_params(top='off', right='off')
axes3[2].set_xlabel('Incom. Poly.', fontsize=15)
axes3[2].tick_params('x', labelsize=9)

plt.subplots_adjust(bottom=None, wspace=0.3)

plt.show()