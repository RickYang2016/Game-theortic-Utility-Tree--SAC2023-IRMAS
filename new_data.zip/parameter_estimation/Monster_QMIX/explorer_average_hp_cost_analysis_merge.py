import matplotlib.pyplot as plt
from dateutil.parser import parse
import time
import numpy as np
import os

fig3, axes3 = plt.subplots(1,3,  gridspec_kw = {'width_ratios':[1, 1, 1]})
fig3.suptitle('25e vs 25m', fontsize=16)

com = [[81.39, 58.49, 41.59, 91.70, 82.18, 69.06, 47.03, 78.42, 64.33, 94.62], \
	   [76.19, 88.25, 84.65, 87.99, 87.32, 82.04, 81.23, 85.98, 81.16, 89.56]]

incom_linear = [[105.14, 105.05, 98.16, 104.16, 106.25, 107.65, 105.65, 106.22, 106.26, 97.91], \
		  	    [129.11, 131.40, 132.34, 133.04, 131.49, 128.04, 114.81, 115.53, 115.65, 126.05]]

incom_ploy = [[107.50, 121.65, 118.18, 120.52, 119.78, 118.13, 118.97, 116.55, 120.50, 118.18], \
		  	  [155.83, 156.39, 150.37, 154.97, 142.13, 149.86, 132.26, 149.95, 156.33, 149.10]]

# com

labels5 = ['$Int.$', '$Int. + Unint.$']

bplot5 = axes3[0].boxplot(com, \
					patch_artist=True, \
					labels=labels5, \
					widths=0.5, \
					boxprops = {'color':'black','facecolor':'#9999ff'}, \
					flierprops = {'marker':'o','markerfacecolor':'white','color':'black'}, \
					whiskerprops = {'color':'black', 'linestyle':'-'})

for i in range(len(bplot5['boxes'])):
	if i == 0:
	    # change outline color
	    bplot5['boxes'][i].set(color='black', linewidth=2)
	    # change fill color
	    bplot5['boxes'][i].set(facecolor = 'green')
	    # change hatch
	    bplot5['boxes'][i].set(hatch = 'x')

	if i == 1:
	    # change outline color
	    bplot5['boxes'][i].set(color='black', linewidth=2)
	    # change fill color
	    bplot5['boxes'][i].set(facecolor = 'green')
	    # change hatch
	    bplot5['boxes'][i].set(hatch = '.')

	# if i == 2:
	#     # change outline color
	#     bplot5['boxes'][i].set(color='black', linewidth=2)
	#     # change fill color
	#     bplot5['boxes'][i].set(facecolor = 'green')
	#     # change hatch
	#     bplot5['boxes'][i].set(hatch = 'x')

colors5 = ['palegreen', 'cyan']
for patch, color in zip(bplot5['boxes'], colors5):
    patch.set_facecolor(color)

axes3[0].tick_params(top='off', right='off')
axes3[0].set_ylabel('Explorer Average HP Cost Winning A Round', fontsize=15)
axes3[0].set_xlabel('Com.', fontsize=15)
axes3[0].tick_params('x', labelsize=9)

# incom_linear

labels6 = ['$Int.$', '$Int. + Unint.$']

bplot6 = axes3[1].boxplot(incom_linear, \
					patch_artist=True, \
					labels=labels6, \
					widths = 0.5,\
					boxprops = {'color':'black','facecolor':'#9999ff'}, \
					flierprops = {'marker':'o','markerfacecolor':'white','color':'black'}, \
					whiskerprops = {'color':'black', 'linestyle':'-'})

for i in range(len(bplot6['boxes'])):
	if i == 0:
	    # change outline color
	    bplot6['boxes'][i].set(color='black', linewidth=2)
	    # change fill color
	    bplot6['boxes'][i].set(facecolor = 'green')
	    # change hatch
	    bplot6['boxes'][i].set(hatch = 'x')

	if i == 1:
	    # change outline color
	    bplot6['boxes'][i].set(color='black', linewidth=2)
	    # change fill color
	    bplot6['boxes'][i].set(facecolor = 'green')
	    # change hatch
	    bplot6['boxes'][i].set(hatch = '.')

	# if i == 2:
	#     # change outline color
	#     bplot6['boxes'][i].set(color='black', linewidth=2)
	#     # change fill color
	#     bplot6['boxes'][i].set(facecolor = 'green')
	#     # change hatch
	#     bplot6['boxes'][i].set(hatch = 'x')

colors6 = ['palegreen', 'cyan']
for patch, color in zip(bplot6['boxes'], colors6):
    patch.set_facecolor(color)

axes3[1].tick_params(top='off', right='off')
axes3[1].set_xlabel('Incom. Linear', fontsize=15)
axes3[1].tick_params('x', labelsize=9)
# axes3[1].set_title('25e vs 25m', fontsize=20)
# incom_ploy

labels7 = ['$Int.$', '$Int. + Unint.$']

bplot7 = axes3[2].boxplot(incom_ploy, \
					patch_artist=True, \
					labels=labels6, \
					widths = 0.5,\
					boxprops = {'color':'black','facecolor':'#9999ff'}, \
					flierprops = {'marker':'o','markerfacecolor':'white','color':'black'}, \
					whiskerprops = {'color':'black', 'linestyle':'-'})

for i in range(len(bplot7['boxes'])):
	if i == 0:
	    # change outline color
	    bplot7['boxes'][i].set(color='black', linewidth=2)
	    # change fill color
	    bplot7['boxes'][i].set(facecolor = 'green')
	    # change hatch
	    bplot7['boxes'][i].set(hatch = 'x')

	if i == 1:
	    # change outline color
	    bplot7['boxes'][i].set(color='black', linewidth=2)
	    # change fill color
	    bplot7['boxes'][i].set(facecolor = 'green')
	    # change hatch
	    bplot7['boxes'][i].set(hatch = '.')

	# if i == 2:
	#     # change outline color
	#     bplot7['boxes'][i].set(color='black', linewidth=2)
	#     # change fill color
	#     bplot7['boxes'][i].set(facecolor = 'green')
	#     # change hatch
	#     bplot7['boxes'][i].set(hatch = 'x')

colors7 = ['palegreen', 'cyan']
for patch, color in zip(bplot7['boxes'], colors7):
    patch.set_facecolor(color)

axes3[2].tick_params(top='off', right='off')
axes3[2].set_xlabel('Incom. Poly.', fontsize=15)
axes3[2].tick_params('x', labelsize=9)

plt.subplots_adjust(bottom=None, wspace=0.3)
# plt.title('25e vs 25m', fontsize=20)

plt.show()