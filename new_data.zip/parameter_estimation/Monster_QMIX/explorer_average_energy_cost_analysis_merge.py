import matplotlib.pyplot as plt
from dateutil.parser import parse
import time
import numpy as np
import os

fig3, axes3 = plt.subplots(1,3,  gridspec_kw = {'width_ratios':[1, 1, 1]})
fig3.suptitle('25e vs 25m', fontsize=16)

com = [[50.32, 42.40, 40.72, 66.95, 48.72, 50.23, 40.24, 45.55, 56.21, 43.09], \
	   [59.46, 58.55, 53.39, 53.53, 56.84, 56.23, 58.95, 65.66, 55.92, 59.01]]

incom_linear = [[50.59, 48.09, 62.13, 59.32, 63.55, 56.36, 51.75, 59.21, 54.91, 66.92], \
		  	    [73.70, 91.29, 85.67, 90.87, 76.30, 68.91, 88.70, 100.59, 88.34, 93.27]]

incom_ploy = [[76.81, 64.81, 59.92, 59.14, 59.93, 67.17, 61.81, 58.68, 147.03, 60.37], \
		  	  [79.43, 96.35, 116.28, 100.01, 93.52, 95.44, 113.64, 105.15, 93.75, 86.99]]

# com

labels5 = ['$Int.$', '$Int. + Unint.$']

bplot5 = axes3[0].boxplot(com, \
					patch_artist=True, \
					labels=labels5, \
					widths=0.5, \
					boxprops = {'color':'black','facecolor':'#9999ff'}, \
					flierprops = {'marker':'o','markerfacecolor':'white','color':'black'}, \
					whiskerprops = {'color':'black', 'linestyle':'-'})

for i in range(len(bplot5['boxes'])):
	if i == 0:
	    # change outline color
	    bplot5['boxes'][i].set(color='black', linewidth=2)
	    # change fill color
	    bplot5['boxes'][i].set(facecolor = 'green')
	    # change hatch
	    bplot5['boxes'][i].set(hatch = 'x')

	if i == 1:
	    # change outline color
	    bplot5['boxes'][i].set(color='black', linewidth=2)
	    # change fill color
	    bplot5['boxes'][i].set(facecolor = 'green')
	    # change hatch
	    bplot5['boxes'][i].set(hatch = '.')

	# if i == 2:
	#     # change outline color
	#     bplot5['boxes'][i].set(color='black', linewidth=2)
	#     # change fill color
	#     bplot5['boxes'][i].set(facecolor = 'green')
	#     # change hatch
	#     bplot5['boxes'][i].set(hatch = 'x')

colors5 = ['palegreen', 'cyan']
for patch, color in zip(bplot5['boxes'], colors5):
    patch.set_facecolor(color)

axes3[0].tick_params(top='off', right='off')
axes3[0].set_ylabel('Explorer Average Energy Cost Winning A Round', fontsize=14)
axes3[0].set_xlabel('Com.', fontsize=15)
axes3[0].tick_params('x', labelsize=9)

# incom_linear

labels6 = ['$Int.$', '$Int. + Unint.$']

bplot6 = axes3[1].boxplot(incom_linear, \
					patch_artist=True, \
					labels=labels6, \
					widths = 0.5,\
					boxprops = {'color':'black','facecolor':'#9999ff'}, \
					flierprops = {'marker':'o','markerfacecolor':'white','color':'black'}, \
					whiskerprops = {'color':'black', 'linestyle':'-'})

for i in range(len(bplot6['boxes'])):
	if i == 0:
	    # change outline color
	    bplot6['boxes'][i].set(color='black', linewidth=2)
	    # change fill color
	    bplot6['boxes'][i].set(facecolor = 'green')
	    # change hatch
	    bplot6['boxes'][i].set(hatch = 'x')

	if i == 1:
	    # change outline color
	    bplot6['boxes'][i].set(color='black', linewidth=2)
	    # change fill color
	    bplot6['boxes'][i].set(facecolor = 'green')
	    # change hatch
	    bplot6['boxes'][i].set(hatch = '.')

	# if i == 2:
	#     # change outline color
	#     bplot6['boxes'][i].set(color='black', linewidth=2)
	#     # change fill color
	#     bplot6['boxes'][i].set(facecolor = 'green')
	#     # change hatch
	#     bplot6['boxes'][i].set(hatch = 'x')

colors6 = ['palegreen', 'cyan']
for patch, color in zip(bplot6['boxes'], colors6):
    patch.set_facecolor(color)

axes3[1].tick_params(top='off', right='off')
axes3[1].set_xlabel('Incom. Linear', fontsize=15)
axes3[1].tick_params('x', labelsize=9)

# incom_ploy

labels7 = ['$Int.$', '$Int. + Unint.$']

bplot7 = axes3[2].boxplot(incom_ploy, \
					patch_artist=True, \
					labels=labels6, \
					widths = 0.5,\
					boxprops = {'color':'black','facecolor':'#9999ff'}, \
					flierprops = {'marker':'o','markerfacecolor':'white','color':'black'}, \
					whiskerprops = {'color':'black', 'linestyle':'-'})

for i in range(len(bplot7['boxes'])):
	if i == 0:
	    # change outline color
	    bplot7['boxes'][i].set(color='black', linewidth=2)
	    # change fill color
	    bplot7['boxes'][i].set(facecolor = 'green')
	    # change hatch
	    bplot7['boxes'][i].set(hatch = 'x')

	if i == 1:
	    # change outline color
	    bplot7['boxes'][i].set(color='black', linewidth=2)
	    # change fill color
	    bplot7['boxes'][i].set(facecolor = 'green')
	    # change hatch
	    bplot7['boxes'][i].set(hatch = '.')

	# if i == 2:
	#     # change outline color
	#     bplot7['boxes'][i].set(color='black', linewidth=2)
	#     # change fill color
	#     bplot7['boxes'][i].set(facecolor = 'green')
	#     # change hatch
	#     bplot7['boxes'][i].set(hatch = 'x')

colors7 = ['palegreen', 'cyan']
for patch, color in zip(bplot7['boxes'], colors7):
    patch.set_facecolor(color)

axes3[2].tick_params(top='off', right='off')
axes3[2].set_xlabel('Incom. Poly.', fontsize=15)
axes3[2].tick_params('x', labelsize=9)

plt.subplots_adjust(bottom=None, wspace=0.3)

plt.show()