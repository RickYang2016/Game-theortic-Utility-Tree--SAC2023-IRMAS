import matplotlib.pyplot as plt
from dateutil.parser import parse
import time
import numpy as np
import os

fig3, axes3 = plt.subplots(1,2,  gridspec_kw = {'width_ratios':[1, 1]})

com_ae_de = [0.06, 0.10, 0.22, 8.40, 100, 100, 100, 100, 100, 100, 100, 4.88, 0.59, 2.65, 0.48, 100, 100]

com_am_dm = [10.00, 2.54, 1.58, 0.33, 0.29, 0.24, 0.18, 0.18, 0.23, 0.22, 0.17, 0.28, 0.26, 0.46, 0.28, 0.24, 0.19]

incom_l_ae_de = [0.03, 0.15, 0.25, 1.39, 30.08, 100, 100, 100, 100, 100, 100, 100, 0.95, 0.61, 9.25, 1.58, 100]

incom_l_am_dm = [13.71, 1.39, 0.60, 0.46, 0.31, 0.31, 0.24, 0.18, 0.20, 0.17, 0.20, 0.31, 0.37, 0.53, 0.37, 0.31, 0.38]

incom_nonl_ae_de = [0.64, 0.16, 0.46, 0.88, 100, 100, 100, 100, 100, 100, 100, 100, 2.10, 0.89, 2.69, 89.00, 100]

incom_nonl_am_dm = [11.29, 1.31, 0.68, 0.56, 0.21, 0.22, 0.23, 0.09, 0.17, 0.20, 0.34, 0.20, 0.34, 0.51, 0.37, 0.25, 0.20]

incom_l_var_ae_de = [incom_l_ae_de[i] - com_ae_de[i] for i in range(len(com_ae_de))]

incom_l_var_am_dm = [incom_l_am_dm[i] - com_am_dm[i] for i in range(len(com_am_dm))]

incom_nonl_var_ae_de = [incom_nonl_ae_de[i] - com_ae_de[i] for i in range(len(com_ae_de))]

incom_nonl_var_am_dm = [incom_nonl_am_dm[i] - com_am_dm[i] for i in range(len(com_am_dm))]

var_ae_de = []
var_ae_de.append(incom_l_var_ae_de)
var_ae_de.append(incom_nonl_var_ae_de)

var_am_dm = []
var_am_dm.append(incom_l_var_am_dm)
var_am_dm.append(incom_nonl_var_am_dm)

ae_de = []
ae_de.append(com_ae_de)
ae_de.append(incom_l_ae_de)
ae_de.append(incom_nonl_ae_de)

am_dm = []
am_dm.append(com_am_dm)
am_dm.append(incom_l_am_dm)
am_dm.append(incom_nonl_am_dm)

# incom_l_ae_de vs incom_nonl_ae_de

labels5 = ['$Incom L$', '$Incom NonL$']

bplot5 = axes3[0].boxplot(var_ae_de, \
					patch_artist=True, \
					labels=labels5, \
					boxprops = {'color':'black','facecolor':'#9999ff'}, \
					flierprops = {'marker':'o','markerfacecolor':'white','color':'black'}, \
					whiskerprops = {'color':'black', 'linestyle':'-'})

for i in range(len(bplot5['boxes'])):
	if i == 0:
	    # change outline color
	    bplot5['boxes'][i].set(color='black', linewidth=2)
	    # change fill color
	    bplot5['boxes'][i].set(facecolor = 'green')
	    # change hatch
	    bplot5['boxes'][i].set(hatch = '/')

	if i == 1:
	    # change outline color
	    bplot5['boxes'][i].set(color='black', linewidth=2)
	    # change fill color
	    bplot5['boxes'][i].set(facecolor = 'green')
	    # change hatch
	    bplot5['boxes'][i].set(hatch = 'o')


colors5 = ['lightblue', 'lightgreen', 'pink']
for patch, color in zip(bplot5['boxes'], colors5):
    patch.set_facecolor(color)

axes3[0].tick_params(top='off', right='off')
axes3[0].set_ylabel('Kill Per Monster HP Cost', fontsize=15)
axes3[0].set_xlabel(r'$\frac{A_e}{D_e}$', fontsize=15)
axes3[0].tick_params('x', labelsize=9)

# incom_l_am_dm vs incom_nonl_am_dm

labels6 = ['$Incom L$', '$Incom NonL$']

bplot6 = axes3[1].boxplot(var_am_dm, \
					patch_artist=True, \
					labels=labels6, \
					widths = 0.5,\
					boxprops = {'color':'black','facecolor':'#9999ff'}, \
					flierprops = {'marker':'o','markerfacecolor':'white','color':'black'}, \
					whiskerprops = {'color':'black', 'linestyle':'-'})

for i in range(len(bplot6['boxes'])):
	if i == 0:
	    # change outline color
	    bplot6['boxes'][i].set(color='black', linewidth=2)
	    # change fill color
	    bplot6['boxes'][i].set(facecolor = 'green')
	    # change hatch
	    bplot6['boxes'][i].set(hatch = '/')

	if i == 1:
	    # change outline color
	    bplot6['boxes'][i].set(color='black', linewidth=2)
	    # change fill color
	    bplot6['boxes'][i].set(facecolor = 'green')
	    # change hatch
	    bplot6['boxes'][i].set(hatch = 'o')


colors6 = ['lightblue', 'lightgreen', 'pink']
for patch, color in zip(bplot6['boxes'], colors6):
    patch.set_facecolor(color)

axes3[1].tick_params(top='off', right='off')
axes3[1].set_xlabel(r'$\frac{A_m}{D_m}$', fontsize=15)
axes3[1].tick_params('x', labelsize=9)


plt.subplots_adjust(bottom=None, wspace=0.3)

plt.show()

# # incom_l_ae_de vs incom_nonl_ae_de

# labels5 = ['$Com$', '$Incom L$', '$Incom NonL$']

# bplot5 = axes3[0].boxplot(ae_de, \
# 					patch_artist=True, \
# 					labels=labels5, \
# 					boxprops = {'color':'black','facecolor':'#9999ff'}, \
# 					flierprops = {'marker':'o','markerfacecolor':'white','color':'black'}, \
# 					whiskerprops = {'color':'black', 'linestyle':'-'})

# for i in range(len(bplot5['boxes'])):
# 	if i == 0:
# 	    # change outline color
# 	    bplot5['boxes'][i].set(color='black', linewidth=2)
# 	    # change fill color
# 	    bplot5['boxes'][i].set(facecolor = 'green')
# 	    # change hatch
# 	    bplot5['boxes'][i].set(hatch = '/')

# 	if i == 1:
# 	    # change outline color
# 	    bplot5['boxes'][i].set(color='black', linewidth=2)
# 	    # change fill color
# 	    bplot5['boxes'][i].set(facecolor = 'green')
# 	    # change hatch
# 	    bplot5['boxes'][i].set(hatch = 'o')


# colors5 = ['lightblue', 'lightgreen', 'pink']
# for patch, color in zip(bplot5['boxes'], colors5):
#     patch.set_facecolor(color)

# axes3[0].tick_params(top='off', right='off')
# axes3[0].set_ylabel('Kill Per Monster HP Cost', fontsize=15)
# axes3[0].set_xlabel(r'$\frac{A_e}{D_e}$', fontsize=15)
# axes3[0].tick_params('x', labelsize=9)

# # incom_l_am_dm vs incom_nonl_am_dm

# labels6 = ['$Com$', '$Incom L$', '$Incom NonL$']

# bplot6 = axes3[1].boxplot(am_dm, \
# 					patch_artist=True, \
# 					labels=labels6, \
# 					widths = 0.5,\
# 					boxprops = {'color':'black','facecolor':'#9999ff'}, \
# 					flierprops = {'marker':'o','markerfacecolor':'white','color':'black'}, \
# 					whiskerprops = {'color':'black', 'linestyle':'-'})

# for i in range(len(bplot6['boxes'])):
# 	if i == 0:
# 	    # change outline color
# 	    bplot6['boxes'][i].set(color='black', linewidth=2)
# 	    # change fill color
# 	    bplot6['boxes'][i].set(facecolor = 'green')
# 	    # change hatch
# 	    bplot6['boxes'][i].set(hatch = '/')

# 	if i == 1:
# 	    # change outline color
# 	    bplot6['boxes'][i].set(color='black', linewidth=2)
# 	    # change fill color
# 	    bplot6['boxes'][i].set(facecolor = 'green')
# 	    # change hatch
# 	    bplot6['boxes'][i].set(hatch = 'o')


# colors6 = ['lightblue', 'lightgreen', 'pink']
# for patch, color in zip(bplot6['boxes'], colors6):
#     patch.set_facecolor(color)

# axes3[1].tick_params(top='off', right='off')
# axes3[1].set_xlabel(r'$\frac{A_m}{D_m}$', fontsize=15)
# axes3[1].tick_params('x', labelsize=9)


# plt.subplots_adjust(bottom=None, wspace=0.3)

# plt.show()