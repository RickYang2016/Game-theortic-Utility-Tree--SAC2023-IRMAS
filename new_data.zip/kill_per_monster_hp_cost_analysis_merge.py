import matplotlib.pyplot as plt
from dateutil.parser import parse
import time
import numpy as np
import os

fig3, axes3 = plt.subplots(1,3,  gridspec_kw = {'width_ratios':[1, 1, 1]})

twenty_five_vs_twenty_five = [[225.47, 208.53, 283.53, 238.29, 235.23, 217.96, 245.36, 236.51, 210.93, 252.60], \
		  					  [197.05, 243.00, 274.08, 226.17, 323.30, 201.99, 233.13, 225.23, 192.24, 198.28], \
		  					  [113.05, 121.86, 103.97, 114.62, 93.39, 123.32, 117.57, 122.53, 107.21, 147.84]]

twenty_vs_thirty = [[198.74, 240.64, 205.51, 273.84, 198.52, 217.46, 217.84, 239.99, 237.93, 212.87], \
		  			[171.64, 245.82, 199.62, 198.51, 249.80, 212.46, 245.55, 215.21, 196.80, 240.84], \
		  			[110.23, 156.47, 119.05, 156.93, 180.73, 146.40, 162.78, 162.38, 145.89, 147.28]]

thirty_vs_twenty = [[222.17, 206.06, 267.52, 230.60, 255.12, 216.40, 208.05, 231.54, 213.10, 272.05], \
		  			[203.90, 219.69, 259.58, 239.96, 231.77, 217.76, 291.56, 250.37, 216.09, 240.79], \
		  			[130.16, 125.39, 114.43, 140.43, 129.63, 150.26, 111.99, 108.71, 113.82, 148.61]]

# 25 vs 25

labels5 = ['$QMIX_{GUT}$', '$QMIX$', '$GUT$']

bplot5 = axes3[0].boxplot(twenty_five_vs_twenty_five, \
					patch_artist=True, \
					labels=labels5, \
					widths=0.5, \
					boxprops = {'color':'black','facecolor':'#9999ff'}, \
					flierprops = {'marker':'o','markerfacecolor':'white','color':'black'}, \
					whiskerprops = {'color':'black', 'linestyle':'-'})

for i in range(len(bplot5['boxes'])):
	if i == 0:
	    # change outline color
	    bplot5['boxes'][i].set(color='black', linewidth=2)
	    # change fill color
	    bplot5['boxes'][i].set(facecolor = 'green')
	    # change hatch
	    bplot5['boxes'][i].set(hatch = '/')

	if i == 1:
	    # change outline color
	    bplot5['boxes'][i].set(color='black', linewidth=2)
	    # change fill color
	    bplot5['boxes'][i].set(facecolor = 'green')
	    # change hatch
	    bplot5['boxes'][i].set(hatch = 'o')

	if i == 2:
	    # change outline color
	    bplot5['boxes'][i].set(color='black', linewidth=2)
	    # change fill color
	    bplot5['boxes'][i].set(facecolor = 'green')
	    # change hatch
	    bplot5['boxes'][i].set(hatch = 'x')

colors5 = ['lightblue', 'lightgreen', 'pink']
for patch, color in zip(bplot5['boxes'], colors5):
    patch.set_facecolor(color)

axes3[0].tick_params(top='off', right='off')
axes3[0].set_ylabel('Kill Per Monster HP Cost', fontsize=15)
axes3[0].set_xlabel('25e vs 25m', fontsize=15)
axes3[0].tick_params('x', labelsize=9)

# 20 vs 30
labels6 = ['$QMIX_{GUT}$', '$QMIX$', '$GUT$']

bplot6 = axes3[1].boxplot(twenty_vs_thirty, \
					patch_artist=True, \
					labels=labels6, \
					widths = 0.5,\
					boxprops = {'color':'black','facecolor':'#9999ff'}, \
					flierprops = {'marker':'o','markerfacecolor':'white','color':'black'}, \
					whiskerprops = {'color':'black', 'linestyle':'-'})

for i in range(len(bplot6['boxes'])):
	if i == 0:
	    # change outline color
	    bplot6['boxes'][i].set(color='black', linewidth=2)
	    # change fill color
	    bplot6['boxes'][i].set(facecolor = 'green')
	    # change hatch
	    bplot6['boxes'][i].set(hatch = '/')

	if i == 1:
	    # change outline color
	    bplot6['boxes'][i].set(color='black', linewidth=2)
	    # change fill color
	    bplot6['boxes'][i].set(facecolor = 'green')
	    # change hatch
	    bplot6['boxes'][i].set(hatch = 'o')

	if i == 2:
	    # change outline color
	    bplot6['boxes'][i].set(color='black', linewidth=2)
	    # change fill color
	    bplot6['boxes'][i].set(facecolor = 'green')
	    # change hatch
	    bplot6['boxes'][i].set(hatch = 'x')

colors6 = ['lightblue', 'lightgreen', 'pink']
for patch, color in zip(bplot6['boxes'], colors6):
    patch.set_facecolor(color)

axes3[1].tick_params(top='off', right='off')
axes3[1].set_xlabel('20e vs 30m', fontsize=15)
axes3[1].tick_params('x', labelsize=9)

# 30 vs 20
labels7 = ['$QMIX_{GUT}$', '$QMIX$', '$GUT$']

bplot7 = axes3[2].boxplot(thirty_vs_twenty, \
					patch_artist=True, \
					labels=labels6, \
					widths = 0.5,\
					boxprops = {'color':'black','facecolor':'#9999ff'}, \
					flierprops = {'marker':'o','markerfacecolor':'white','color':'black'}, \
					whiskerprops = {'color':'black', 'linestyle':'-'})

for i in range(len(bplot7['boxes'])):
	if i == 0:
	    # change outline color
	    bplot7['boxes'][i].set(color='black', linewidth=2)
	    # change fill color
	    bplot7['boxes'][i].set(facecolor = 'green')
	    # change hatch
	    bplot7['boxes'][i].set(hatch = '/')

	if i == 1:
	    # change outline color
	    bplot7['boxes'][i].set(color='black', linewidth=2)
	    # change fill color
	    bplot7['boxes'][i].set(facecolor = 'green')
	    # change hatch
	    bplot7['boxes'][i].set(hatch = 'o')

	if i == 2:
	    # change outline color
	    bplot7['boxes'][i].set(color='black', linewidth=2)
	    # change fill color
	    bplot7['boxes'][i].set(facecolor = 'green')
	    # change hatch
	    bplot7['boxes'][i].set(hatch = 'x')

colors7 = ['lightblue', 'lightgreen', 'pink']
for patch, color in zip(bplot7['boxes'], colors7):
    patch.set_facecolor(color)

axes3[2].tick_params(top='off', right='off')
axes3[2].set_xlabel('30e vs 20m', fontsize=15)
axes3[2].tick_params('x', labelsize=9)

plt.subplots_adjust(bottom=None, wspace=0.3)

plt.show()