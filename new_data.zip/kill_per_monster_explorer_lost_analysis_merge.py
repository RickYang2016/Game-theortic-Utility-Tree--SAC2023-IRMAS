import matplotlib.pyplot as plt
from dateutil.parser import parse
import time
import numpy as np
import os

fig3, axes3 = plt.subplots(1,3,  gridspec_kw = {'width_ratios':[1, 1, 1]})

twenty_five_vs_twenty_five = [[2.50, 2.09, 2.88, 2.30, 2.40, 2.00, 2.13, 1.75, 1.73, 2.33], \
		  					  [1.75, 2.11, 2.38, 1.78, 2.29, 2.00, 2.10, 1.70, 1.75, 1.83], \
		  					  [0.94, 1.33, 0.30, 1.15, 0.91, 0.79, 0.20, 0.94, 0.53, 1.44]]

twenty_vs_thirty = [[2.00, 2.50, 2.11, 2.57, 2.00, 2.11, 2.22, 2.13, 2.50, 2.22], \
		  			[1.82, 2.50, 2.00, 2.00, 2.50, 2.00, 2.50, 2.11, 2.00, 2.13], \
		  			[1.12, 1.50, 0.64, 1.50, 1.82, 1.46, 1.67, 1.67, 1.46, 1.46]]

thirty_vs_twenty = [[1.82, 1.83, 2.33, 1.80, 2.44, 1.64, 1.92, 2.09, 1.75, 2.11], \
		  			[1.36, 2.00, 2.50, 1.80, 1.82, 1.75, 2.25, 1.56, 1.75, 1.90], \
		  			[0.90, 0.95, 0.62, 1.17, 1.11, 1.50, 0.76, 0.75, 0.65, 1.07]]

# 25 vs 25

labels5 = ['$QMIX_{GUT}$', '$QMIX$', '$GUT$']

bplot5 = axes3[0].boxplot(twenty_five_vs_twenty_five, \
					patch_artist=True, \
					labels=labels5, \
					widths=0.5, \
					boxprops = {'color':'black','facecolor':'#9999ff'}, \
					flierprops = {'marker':'o','markerfacecolor':'white','color':'black'}, \
					whiskerprops = {'color':'black', 'linestyle':'-'})

for i in range(len(bplot5['boxes'])):
	if i == 0:
	    # change outline color
	    bplot5['boxes'][i].set(color='black', linewidth=2)
	    # change fill color
	    bplot5['boxes'][i].set(facecolor = 'green')
	    # change hatch
	    bplot5['boxes'][i].set(hatch = '/')

	if i == 1:
	    # change outline color
	    bplot5['boxes'][i].set(color='black', linewidth=2)
	    # change fill color
	    bplot5['boxes'][i].set(facecolor = 'green')
	    # change hatch
	    bplot5['boxes'][i].set(hatch = 'o')

	if i == 2:
	    # change outline color
	    bplot5['boxes'][i].set(color='black', linewidth=2)
	    # change fill color
	    bplot5['boxes'][i].set(facecolor = 'green')
	    # change hatch
	    bplot5['boxes'][i].set(hatch = 'x')

colors5 = ['lightblue', 'lightgreen', 'pink']
for patch, color in zip(bplot5['boxes'], colors5):
    patch.set_facecolor(color)

axes3[0].tick_params(top='off', right='off')
axes3[0].set_ylabel('Kill Per Monster Explorer Lost', fontsize=15)
axes3[0].set_xlabel('25e vs 25m', fontsize=15)
axes3[0].tick_params('x', labelsize=9)

# 20 vs 30
labels6 = ['$QMIX_{GUT}$', '$QMIX$', '$GUT$']

bplot6 = axes3[1].boxplot(twenty_vs_thirty, \
					patch_artist=True, \
					labels=labels6, \
					widths = 0.5,\
					boxprops = {'color':'black','facecolor':'#9999ff'}, \
					flierprops = {'marker':'o','markerfacecolor':'white','color':'black'}, \
					whiskerprops = {'color':'black', 'linestyle':'-'})

for i in range(len(bplot6['boxes'])):
	if i == 0:
	    # change outline color
	    bplot6['boxes'][i].set(color='black', linewidth=2)
	    # change fill color
	    bplot6['boxes'][i].set(facecolor = 'green')
	    # change hatch
	    bplot6['boxes'][i].set(hatch = '/')

	if i == 1:
	    # change outline color
	    bplot6['boxes'][i].set(color='black', linewidth=2)
	    # change fill color
	    bplot6['boxes'][i].set(facecolor = 'green')
	    # change hatch
	    bplot6['boxes'][i].set(hatch = 'o')

	if i == 2:
	    # change outline color
	    bplot6['boxes'][i].set(color='black', linewidth=2)
	    # change fill color
	    bplot6['boxes'][i].set(facecolor = 'green')
	    # change hatch
	    bplot6['boxes'][i].set(hatch = 'x')

colors6 = ['lightblue', 'lightgreen', 'pink']
for patch, color in zip(bplot6['boxes'], colors6):
    patch.set_facecolor(color)

axes3[1].tick_params(top='off', right='off')
axes3[1].set_xlabel('20e vs 30m', fontsize=15)
axes3[1].tick_params('x', labelsize=9)

# 30 vs 20
labels7 = ['$QMIX_{GUT}$', '$QMIX$', '$GUT$']

bplot7 = axes3[2].boxplot(thirty_vs_twenty, \
					patch_artist=True, \
					labels=labels6, \
					widths = 0.5,\
					boxprops = {'color':'black','facecolor':'#9999ff'}, \
					flierprops = {'marker':'o','markerfacecolor':'white','color':'black'}, \
					whiskerprops = {'color':'black', 'linestyle':'-'})

for i in range(len(bplot7['boxes'])):
	if i == 0:
	    # change outline color
	    bplot7['boxes'][i].set(color='black', linewidth=2)
	    # change fill color
	    bplot7['boxes'][i].set(facecolor = 'green')
	    # change hatch
	    bplot7['boxes'][i].set(hatch = '/')

	if i == 1:
	    # change outline color
	    bplot7['boxes'][i].set(color='black', linewidth=2)
	    # change fill color
	    bplot7['boxes'][i].set(facecolor = 'green')
	    # change hatch
	    bplot7['boxes'][i].set(hatch = 'o')

	if i == 2:
	    # change outline color
	    bplot7['boxes'][i].set(color='black', linewidth=2)
	    # change fill color
	    bplot7['boxes'][i].set(facecolor = 'green')
	    # change hatch
	    bplot7['boxes'][i].set(hatch = 'x')

colors7 = ['lightblue', 'lightgreen', 'pink']
for patch, color in zip(bplot7['boxes'], colors7):
    patch.set_facecolor(color)

axes3[2].tick_params(top='off', right='off')
axes3[2].set_xlabel('30e vs 20m', fontsize=15)
axes3[2].tick_params('x', labelsize=9)

plt.subplots_adjust(bottom=None, wspace=0.3)

plt.show()