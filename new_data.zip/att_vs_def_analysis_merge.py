import matplotlib.pyplot as plt
from dateutil.parser import parse
import time
import numpy as np
import os

fig3, axes3 = plt.subplots(1,3,  gridspec_kw = {'width_ratios':[1, 1, 1]})

twenty_five_vs_twenty_five = [[0.13, 0.14, 0.12, 0.13, 0.14, 0.17, 0.16, 0.19, 0.11, 0.26], \
		  			[8.36, 10.20, 5.12, 4.14, 5.70, 4.75, 4.04, 5.01, 10.80, 9.17], \
		  			[100, 100, 100, 25.79, 100, 100, 100, 100, 100, 5.94]]

twenty_vs_thirty = [[0.09, 0.05, 0.17, 0.10, 0.08, 0.06, 0.10, 0.18, 0.07, 0.20], \
		  					  [12.87, 7.32, 10.28, 10.09, 9.87, 14.47, 9.17, 7.56, 13.19, 9.36], \
		  					  [8.40, 2.19, 3.62, 0.73, 0.38, 2.41, 0.22, 0.72, 2.30, 1.08]]

thirty_vs_twenty = [[0.31, 0.22, 0.19, 0.23, 0.25, 0.19, 0.23, 0.14, 0.22, 0.24], \
		  			[6.67, 6.87, 5.58, 6.13, 6.20, 7.07, 8.67, 5.31, 5.47, 4.40], \
		  			[2.98, 3.15, 100, 3.75, 53.83, 26.06, 100, 100, 100, 12.50]]

# 25 vs 25

labels5 = ['$QMIX_{GUT}$', '$QMIX$', '$GUT$']

bplot5 = axes3[0].boxplot(twenty_five_vs_twenty_five, \
					patch_artist=True, \
					labels=labels5, \
					boxprops = {'color':'black','facecolor':'#9999ff'}, \
					flierprops = {'marker':'o','markerfacecolor':'white','color':'black'}, \
					whiskerprops = {'color':'black', 'linestyle':'-'})

for i in range(len(bplot5['boxes'])):
	if i == 0:
	    # change outline color
	    bplot5['boxes'][i].set(color='black', linewidth=2)
	    # change fill color
	    bplot5['boxes'][i].set(facecolor = 'green')
	    # change hatch
	    bplot5['boxes'][i].set(hatch = '/')

	if i == 1:
	    # change outline color
	    bplot5['boxes'][i].set(color='black', linewidth=2)
	    # change fill color
	    bplot5['boxes'][i].set(facecolor = 'green')
	    # change hatch
	    bplot5['boxes'][i].set(hatch = 'o')

	if i == 2:
	    # change outline color
	    bplot5['boxes'][i].set(color='black', linewidth=2)
	    # change fill color
	    bplot5['boxes'][i].set(facecolor = 'green')
	    # change hatch
	    bplot5['boxes'][i].set(hatch = 'x')

colors5 = ['lightblue', 'lightgreen', 'pink']
for patch, color in zip(bplot5['boxes'], colors5):
    patch.set_facecolor(color)

axes3[0].tick_params(top='off', right='off')
axes3[0].set_ylabel(r'$\frac{A_e}{D_e}$', fontsize=18, rotation=0)
axes3[0].set_xlabel('25e vs 25m', fontsize=15)
axes3[0].tick_params('x', labelsize=9)

# 20 vs 30
labels6 = ['$QMIX_{GUT}$', '$QMIX$', '$GUT$']

bplot6 = axes3[1].boxplot(twenty_vs_thirty, \
					patch_artist=True, \
					labels=labels6, \
					widths = 0.5,\
					boxprops = {'color':'black','facecolor':'#9999ff'}, \
					flierprops = {'marker':'o','markerfacecolor':'white','color':'black'}, \
					whiskerprops = {'color':'black', 'linestyle':'-'})

for i in range(len(bplot6['boxes'])):
	if i == 0:
	    # change outline color
	    bplot6['boxes'][i].set(color='black', linewidth=2)
	    # change fill color
	    bplot6['boxes'][i].set(facecolor = 'green')
	    # change hatch
	    bplot6['boxes'][i].set(hatch = '/')

	if i == 1:
	    # change outline color
	    bplot6['boxes'][i].set(color='black', linewidth=2)
	    # change fill color
	    bplot6['boxes'][i].set(facecolor = 'green')
	    # change hatch
	    bplot6['boxes'][i].set(hatch = 'o')

	if i == 2:
	    # change outline color
	    bplot6['boxes'][i].set(color='black', linewidth=2)
	    # change fill color
	    bplot6['boxes'][i].set(facecolor = 'green')
	    # change hatch
	    bplot6['boxes'][i].set(hatch = 'x')

colors6 = ['lightblue', 'lightgreen', 'pink']
for patch, color in zip(bplot6['boxes'], colors6):
    patch.set_facecolor(color)

axes3[1].tick_params(top='off', right='off')
axes3[1].set_xlabel('20e vs 30m', fontsize=15)
axes3[1].tick_params('x', labelsize=9)

# 30 vs 20
labels7 = ['$QMIX_{GUT}$', '$QMIX$', '$GUT$']

bplot7 = axes3[2].boxplot(thirty_vs_twenty, \
					patch_artist=True, \
					labels=labels6, \
					widths = 0.5,\
					boxprops = {'color':'black','facecolor':'#9999ff'}, \
					flierprops = {'marker':'o','markerfacecolor':'white','color':'black'}, \
					whiskerprops = {'color':'black', 'linestyle':'-'})

for i in range(len(bplot7['boxes'])):
	if i == 0:
	    # change outline color
	    bplot7['boxes'][i].set(color='black', linewidth=2)
	    # change fill color
	    bplot7['boxes'][i].set(facecolor = 'green')
	    # change hatch
	    bplot7['boxes'][i].set(hatch = '/')

	if i == 1:
	    # change outline color
	    bplot7['boxes'][i].set(color='black', linewidth=2)
	    # change fill color
	    bplot7['boxes'][i].set(facecolor = 'green')
	    # change hatch
	    bplot7['boxes'][i].set(hatch = 'o')

	if i == 2:
	    # change outline color
	    bplot7['boxes'][i].set(color='black', linewidth=2)
	    # change fill color
	    bplot7['boxes'][i].set(facecolor = 'green')
	    # change hatch
	    bplot7['boxes'][i].set(hatch = 'x')

colors7 = ['lightblue', 'lightgreen', 'pink']
for patch, color in zip(bplot7['boxes'], colors7):
    patch.set_facecolor(color)

axes3[2].tick_params(top='off', right='off')
axes3[2].set_xlabel('30e vs 20m', fontsize=15)
axes3[2].tick_params('x', labelsize=9)

plt.subplots_adjust(bottom=None, wspace=0.3)

plt.show()