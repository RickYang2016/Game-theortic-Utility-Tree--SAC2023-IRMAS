import matplotlib.pyplot as plt
from dateutil.parser import parse
import time
import math
import numpy as np
import os
import itertools as it
from datetime import datetime
from sklearn.linear_model import LinearRegression


complete_info_25e = "/home/herobot/Documents/research/data/explorer_game/com/1"
complete_info_25m = "/home/herobot/Documents/research/data/explorer_game/com/2"
complete_info_50 = "/home/herobot/Documents/research/data/explorer_game/com/3"
complete_info = "/home/herobot/Documents/research/data/explorer_game/com/4"

incomplete_info_linear_25e = "/home/herobot/Documents/research/data/explorer_game/incom_linear/1"
incomplete_info_linear_25m = "/home/herobot/Documents/research/data/explorer_game/incom_linear/2"
incomplete_info_linear_50 = "/home/herobot/Documents/research/data/explorer_game/incom_linear/3"
incomplete_info_linear = "/home/herobot/Documents/research/data/explorer_game/incom_linear/4"

incomplete_info_nonlinear_25e = "/home/herobot/Documents/research/data/explorer_game/incom_nonlinear/1"
incomplete_info_nonlinear_25m = "/home/herobot/Documents/research/data/explorer_game/incom_nonlinear/2"
incomplete_info_nonlinear_50 = "/home/herobot/Documents/research/data/explorer_game/incom_nonlinear/3"

incomplete_info_Polynomial_Regression = "/home/herobot/Documents/research/data/explorer_game/Polynomial_Regression/4"

noncooperation_info_25e = "/home/herobot/Documents/research/data/explorer_game/noncooperate/1"
noncooperation_info_25m = "/home/herobot/Documents/research/data/explorer_game/noncooperate/2"
noncooperation_info_50 = "/home/herobot/Documents/research/data/explorer_game/noncooperate/3"
noncooperation_info = "/home/herobot/Documents/research/data/explorer_game/noncooperate/4"


files11 = os.listdir(complete_info_25e)
files12 = os.listdir(complete_info_25m)
files13 = os.listdir(complete_info_50)
files14 = os.listdir(complete_info)

files21 = os.listdir(incomplete_info_linear_25e)
files22 = os.listdir(incomplete_info_linear_25m)
files23 = os.listdir(incomplete_info_linear_50)
files24 = os.listdir(incomplete_info_linear)

files31 = os.listdir(incomplete_info_nonlinear_25e)
files32 = os.listdir(incomplete_info_nonlinear_25m)
files33 = os.listdir(incomplete_info_nonlinear_50)

files54 = os.listdir(incomplete_info_Polynomial_Regression)


files41 = os.listdir(noncooperation_info_25e)
files42 = os.listdir(noncooperation_info_25m)
files43 = os.listdir(noncooperation_info_50)
files44 = os.listdir(noncooperation_info)

# complete info 
# 25 explorers fixed
for file11 in files11:
	if not os.path.isdir(file11):
		ratio11, kill_per_monster_HP_cost11, kill_per_monster_number_of_explorers_losing11, complete_task_each_explorer_energy_cost11, complete_task_each_explorer_HP_cost11 = [],[],[],[],[]
		f11 = open(complete_info_25e + "/" + file11, "r");

		for line in f11:
			value11 = [str(s) for s in line.split()]
			ratio11.append(math.log(float(value11[0]), 10))
			kill_per_monster_HP_cost11.append(float(value11[1]))
			kill_per_monster_number_of_explorers_losing11.append(float(value11[2]))
			complete_task_each_explorer_energy_cost11.append(float(value11[3]))
			complete_task_each_explorer_HP_cost11.append(float(value11[4]))

# 25 monsters fixed
for file12 in files12:
	if not os.path.isdir(file12):
		ratio12, kill_per_monster_HP_cost12, kill_per_monster_number_of_explorers_losing12, complete_task_each_explorer_energy_cost12, complete_task_each_explorer_HP_cost12 = [],[],[],[],[]
		f12 = open(complete_info_25m + "/" + file12, "r");

		for line in f12:
			value12 = [str(s) for s in line.split()]
			ratio12.append(math.log(float(value12[0]), 10))
			kill_per_monster_HP_cost12.append(float(value12[1]))
			kill_per_monster_number_of_explorers_losing12.append(float(value12[2]))
			complete_task_each_explorer_energy_cost12.append(float(value12[3]))
			complete_task_each_explorer_HP_cost12.append(float(value12[4]))

# 50 agents fixed
for file13 in files13:
	if not os.path.isdir(file13):
		ratio13, kill_per_monster_HP_cost13, kill_per_monster_number_of_explorers_losing13, complete_task_each_explorer_energy_cost13, complete_task_each_explorer_HP_cost13 = [],[],[],[],[]
		f13 = open(complete_info_50 + "/" + file13, "r");

		for line in f13:
			value13 = [str(s) for s in line.split()]
			ratio13.append(math.log(float(value13[0]), 10))
			kill_per_monster_HP_cost13.append(float(value13[1]))
			kill_per_monster_number_of_explorers_losing13.append(float(value13[2]))
			complete_task_each_explorer_energy_cost13.append(float(value13[3]))
			complete_task_each_explorer_HP_cost13.append(float(value13[4]))

# all agents
for file14 in files14:
	if not os.path.isdir(file14):
		ratio14, kill_per_monster_HP_cost14, kill_per_monster_number_of_explorers_losing14, complete_task_each_explorer_energy_cost14, complete_task_each_explorer_HP_cost14 = [],[],[],[],[]
		f14 = open(complete_info + "/" + file14, "r");

		for line in f14:
			value14 = [str(s) for s in line.split()]
			ratio14.append(math.log(float(value14[0]), 10))
			kill_per_monster_HP_cost14.append(float(value14[1]))
			kill_per_monster_number_of_explorers_losing14.append(float(value14[2]))
			complete_task_each_explorer_energy_cost14.append(float(value14[3]))
			complete_task_each_explorer_HP_cost14.append(float(value14[4]))


# incomplete info
# 25 explorers fixed linear
for file21 in files21:
	if not os.path.isdir(file21):
		ratio21, kill_per_monster_HP_cost21, kill_per_monster_number_of_explorers_losing21, complete_task_each_explorer_energy_cost21, complete_task_each_explorer_HP_cost21 = [],[],[],[],[]
		f21 = open(incomplete_info_linear_25e + "/" + file21, "r");

		for line in f21:
			value21 = [str(s) for s in line.split()]
			ratio21.append(math.log(float(value21[0]), 10))
			kill_per_monster_HP_cost21.append(float(value21[1]))
			kill_per_monster_number_of_explorers_losing21.append(float(value21[2]))
			complete_task_each_explorer_energy_cost21.append(float(value21[3]))
			complete_task_each_explorer_HP_cost21.append(float(value21[4]))

# 25 monsters fixed linear
for file22 in files22:
	if not os.path.isdir(file22):
		ratio22, kill_per_monster_HP_cost22, kill_per_monster_number_of_explorers_losing22, complete_task_each_explorer_energy_cost22, complete_task_each_explorer_HP_cost22 = [],[],[],[],[]
		f22 = open(incomplete_info_linear_25m + "/" + file22, "r");

		for line in f22:
			value22 = [str(s) for s in line.split()]
			ratio22.append(math.log(float(value22[0]), 10))
			kill_per_monster_HP_cost22.append(float(value22[1]))
			kill_per_monster_number_of_explorers_losing22.append(float(value22[2]))
			complete_task_each_explorer_energy_cost22.append(float(value22[3]))
			complete_task_each_explorer_HP_cost22.append(float(value22[4]))

# 50 agents fixed
for file23 in files23:
	if not os.path.isdir(file23):
		ratio23, kill_per_monster_HP_cost23, kill_per_monster_number_of_explorers_losing23, complete_task_each_explorer_energy_cost23, complete_task_each_explorer_HP_cost23 = [],[],[],[],[]
		f23 = open(incomplete_info_linear_50 + "/" + file23, "r");

		for line in f23:
			value23 = [str(s) for s in line.split()]
			ratio23.append(math.log(float(value23[0]), 10))
			kill_per_monster_HP_cost23.append(float(value23[1]))
			kill_per_monster_number_of_explorers_losing23.append(float(value23[2]))
			complete_task_each_explorer_energy_cost23.append(float(value23[3]))
			complete_task_each_explorer_HP_cost23.append(float(value23[4]))

# all agents
for file24 in files24:
	if not os.path.isdir(file24):
		ratio24, kill_per_monster_HP_cost24, kill_per_monster_number_of_explorers_losing24, complete_task_each_explorer_energy_cost24, complete_task_each_explorer_HP_cost24 = [],[],[],[],[]
		f24 = open(incomplete_info_linear + "/" + file24, "r");

		for line in f24:
			value24 = [str(s) for s in line.split()]
			ratio24.append(math.log(float(value24[0]), 10))
			kill_per_monster_HP_cost24.append(float(value24[1]))
			kill_per_monster_number_of_explorers_losing24.append(float(value24[2]))
			complete_task_each_explorer_energy_cost24.append(float(value24[3]))
			complete_task_each_explorer_HP_cost24.append(float(value24[4]))

# incomplete info 
# 25 explorers fixed nonlinear
for file31 in files31:
	if not os.path.isdir(file31):
		ratio31, kill_per_monster_HP_cost31, kill_per_monster_number_of_explorers_losing31, complete_task_each_explorer_energy_cost31, complete_task_each_explorer_HP_cost31 = [],[],[],[],[]
		f31 = open(incomplete_info_nonlinear_25e + "/" + file31, "r");

		for line in f31:
			value31 = [str(s) for s in line.split()]
			ratio31.append(math.log(float(value31[0]), 10))
			kill_per_monster_HP_cost31.append(float(value31[1]))
			kill_per_monster_number_of_explorers_losing31.append(float(value31[2]))
			complete_task_each_explorer_energy_cost31.append(float(value31[3]))
			complete_task_each_explorer_HP_cost31.append(float(value31[4]))

# 25 monsters fixed nonlinear
for file32 in files32:
	if not os.path.isdir(file32):
		ratio32, kill_per_monster_HP_cost32, kill_per_monster_number_of_explorers_losing32, complete_task_each_explorer_energy_cost32, complete_task_each_explorer_HP_cost32 = [],[],[],[],[]
		f32 = open(incomplete_info_nonlinear_25m + "/" + file32, "r");

		for line in f32:
			value32 = [str(s) for s in line.split()]
			ratio32.append(math.log(float(value32[0]), 10))
			kill_per_monster_HP_cost32.append(float(value32[1]))
			kill_per_monster_number_of_explorers_losing32.append(float(value32[2]))
			complete_task_each_explorer_energy_cost32.append(float(value32[3]))
			complete_task_each_explorer_HP_cost32.append(float(value32[4]))

# 50 agents fixed
for file33 in files33:
	if not os.path.isdir(file33):
		ratio33, kill_per_monster_HP_cost33, kill_per_monster_number_of_explorers_losing33, complete_task_each_explorer_energy_cost33, complete_task_each_explorer_HP_cost33 = [],[],[],[],[]
		f33 = open(incomplete_info_nonlinear_50 + "/" + file33, "r");

		for line in f33:
			value33 = [str(s) for s in line.split()]
			ratio33.append(math.log(float(value33[0]), 10))
			kill_per_monster_HP_cost33.append(float(value33[1]))
			kill_per_monster_number_of_explorers_losing33.append(float(value33[2]))
			complete_task_each_explorer_energy_cost33.append(float(value33[3]))
			complete_task_each_explorer_HP_cost33.append(float(value33[4]))

# noncooperation info 
# 25 explorers fixed nonlinear
for file41 in files41:
	if not os.path.isdir(file41):
		ratio41, kill_per_monster_HP_cost41, kill_per_monster_number_of_explorers_losing41, complete_task_each_explorer_energy_cost41, complete_task_each_explorer_HP_cost41 = [],[],[],[],[]
		f41 = open(noncooperation_info_25e + "/" + file41, "r");

		for line in f41:
			value41 = [str(s) for s in line.split()]
			ratio41.append(math.log(float(value41[0]), 10))
			kill_per_monster_HP_cost41.append(float(value41[1]))
			kill_per_monster_number_of_explorers_losing41.append(float(value41[2]))
			complete_task_each_explorer_energy_cost41.append(float(value41[3]))
			complete_task_each_explorer_HP_cost41.append(float(value41[4]))

# 25 monsters fixed nonlinear
for file42 in files42:
	if not os.path.isdir(file42):
		ratio42, kill_per_monster_HP_cost42, kill_per_monster_number_of_explorers_losing42, complete_task_each_explorer_energy_cost42, complete_task_each_explorer_HP_cost42 = [],[],[],[],[]
		f42 = open(noncooperation_info_25m + "/" + file42, "r");

		for line in f42:
			value42 = [str(s) for s in line.split()]
			ratio42.append(math.log(float(value42[0]), 10))
			kill_per_monster_HP_cost42.append(float(value42[1]))
			kill_per_monster_number_of_explorers_losing42.append(float(value42[2]))
			complete_task_each_explorer_energy_cost42.append(float(value42[3]))
			complete_task_each_explorer_HP_cost42.append(float(value42[4]))

# 50 agents fixed
for file43 in files43:
	if not os.path.isdir(file43):
		ratio43, kill_per_monster_HP_cost43, kill_per_monster_number_of_explorers_losing43, complete_task_each_explorer_energy_cost43, complete_task_each_explorer_HP_cost43 = [],[],[],[],[]
		f43 = open(noncooperation_info_50 + "/" + file43, "r");

		for line in f43:
			value43 = [str(s) for s in line.split()]
			ratio43.append(math.log(float(value43[0]), 10))
			kill_per_monster_HP_cost43.append(float(value43[1]))
			kill_per_monster_number_of_explorers_losing43.append(float(value43[2]))
			complete_task_each_explorer_energy_cost43.append(float(value43[3]))
			complete_task_each_explorer_HP_cost43.append(float(value43[4]))

# all agents
for file44 in files44:
	if not os.path.isdir(file44):
		ratio44, kill_per_monster_HP_cost44, kill_per_monster_number_of_explorers_losing44, complete_task_each_explorer_energy_cost44, complete_task_each_explorer_HP_cost44 = [],[],[],[],[]
		f44 = open(noncooperation_info + "/" + file44, "r");

		for line in f44:
			value44 = [str(s) for s in line.split()]
			ratio44.append(math.log(float(value44[0]), 10))
			kill_per_monster_HP_cost44.append(float(value44[1]))
			kill_per_monster_number_of_explorers_losing44.append(float(value44[2]))
			complete_task_each_explorer_energy_cost44.append(float(value44[3]))
			complete_task_each_explorer_HP_cost44.append(float(value44[4]))

# Polynomial Regression all agents
for file54 in files54:
	if not os.path.isdir(file54):
		ratio54, kill_per_monster_HP_cost54, kill_per_monster_number_of_explorers_losing54, complete_task_each_explorer_energy_cost54, complete_task_each_explorer_HP_cost54 = [],[],[],[],[]
		f54 = open(incomplete_info_Polynomial_Regression + "/" + file54, "r");

		for line in f54:
			value54 = [str(s) for s in line.split()]
			ratio54.append(math.log(float(value54[0]), 10))
			kill_per_monster_HP_cost54.append(float(value54[1]))
			kill_per_monster_number_of_explorers_losing54.append(float(value54[2]))
			complete_task_each_explorer_energy_cost54.append(float(value54[3]))
			complete_task_each_explorer_HP_cost54.append(float(value54[4]))

# 25 explorers fixed
# ==========================================================================================================

# plt.figure()
# plt.title('(a) SC.1 - Fixed Explorers (E=25)', fontsize = 15)
# plt.scatter(ratio11, kill_per_monster_HP_cost11, marker = 'p')
# plt.scatter(ratio21, kill_per_monster_HP_cost21, marker = '^')
# plt.scatter(ratio31, kill_per_monster_HP_cost31, marker = '*')
# plt.scatter(ratio41, kill_per_monster_HP_cost41)

# plt.scatter(ratio11[4:], kill_per_monster_HP_cost11[4:], color = '', marker = 'o', edgecolors = 'indigo', s = 150)
# plt.scatter(ratio21[4:], kill_per_monster_HP_cost21[4:], color = '', marker = 'o', edgecolors = 'indigo', s = 150)
# plt.scatter(ratio31[4:], kill_per_monster_HP_cost31[4:], color = '', marker = 'o', edgecolors = 'indigo', s = 150)
# plt.scatter(ratio41, kill_per_monster_HP_cost41, color = '', marker = 'o', edgecolors = 'indigo', s = 150)

# plt.xlabel('log(Ratio(M/E))', fontsize = 15)
# plt.ylabel('Exp. HP Cost Per Kill Monster', fontsize = 15)
# plt.legend(['Coop. Full Info.','Coop. Linear Pred.', 'Coop. Nonlinear Pred.', 'Noncooperation', 'Incomplete Task Label'], loc='lower right', bbox_to_anchor=(1, 0.15))
# plt.show()

# plt.figure()
# plt.title('(b) SC.1 - Fixed Explorers (E=25)', fontsize = 15)
# plt.scatter(ratio11, kill_per_monster_number_of_explorers_losing11, marker = 'p')
# plt.scatter(ratio21, kill_per_monster_number_of_explorers_losing21, marker = '^')
# plt.scatter(ratio31, kill_per_monster_number_of_explorers_losing31, marker = '*')
# plt.scatter(ratio41, kill_per_monster_number_of_explorers_losing41)

# plt.scatter(ratio11[4:], kill_per_monster_number_of_explorers_losing11[4:], color = '', marker = 'o', edgecolors = 'indigo', s = 150)
# plt.scatter(ratio21[4:], kill_per_monster_number_of_explorers_losing21[4:], color = '', marker = 'o', edgecolors = 'indigo', s = 150)
# plt.scatter(ratio31[4:], kill_per_monster_number_of_explorers_losing31[4:], color = '', marker = 'o', edgecolors = 'indigo', s = 150)
# plt.scatter(ratio41, kill_per_monster_number_of_explorers_losing41, color = '', marker = 'o', edgecolors = 'indigo', s = 150)

# plt.xlabel('log(Ratio(M/E))', fontsize = 15)
# plt.ylabel('#Exp. Lost Per Kill Monster', fontsize = 15)
# plt.legend(['Coop. Full Info.','Coop. Linear Pred.', 'Coop. Nonlinear Pred.', 'Noncooperation', 'Incomplete Task Label'])
# plt.show()

# plt.figure()
# plt.title('(d) SC.1 - Fixed Explorers (E=25)', fontsize = 15)
# plt.scatter(ratio11, complete_task_each_explorer_energy_cost11, marker = 'p')
# plt.scatter(ratio21, complete_task_each_explorer_energy_cost21, marker = '^')
# plt.scatter(ratio31, complete_task_each_explorer_energy_cost31, marker = '*')
# plt.scatter(ratio41, complete_task_each_explorer_energy_cost41)

# plt.scatter(ratio11[4:], complete_task_each_explorer_energy_cost11[4:], color = '', marker = 'o', edgecolors = 'indigo', s = 150)
# plt.scatter(ratio21[4:], complete_task_each_explorer_energy_cost21[4:], color = '', marker = 'o', edgecolors = 'indigo', s = 150)
# plt.scatter(ratio31[4:], complete_task_each_explorer_energy_cost31[4:], color = '', marker = 'o', edgecolors = 'indigo', s = 150)
# plt.scatter(ratio41, complete_task_each_explorer_energy_cost41, color = '', marker = 'o', edgecolors = 'indigo', s = 150)

# plt.xlabel('log(Ratio(M/E))', fontsize = 15)
# plt.ylabel('Exp. Average Energy Cost', fontsize = 15)
# plt.legend(['Coop. Full Info.','Coop. Linear Pred.', 'Coop. Nonlinear Pred.', 'Noncooperation', 'Incomplete Task Label'])
# plt.show()

# plt.figure()
# plt.title('(c) SC.1 - Fixed Explorers (E=25)', fontsize = 15)
# plt.scatter(ratio11, complete_task_each_explorer_HP_cost11, marker = 'p')
# plt.scatter(ratio21, complete_task_each_explorer_HP_cost21, marker = '^')
# plt.scatter(ratio31, complete_task_each_explorer_HP_cost31, marker = '*')
# plt.scatter(ratio41, complete_task_each_explorer_HP_cost41)

# plt.scatter(ratio11[4:], complete_task_each_explorer_HP_cost11[4:], color = '', marker = 'o', edgecolors = 'indigo', s = 150)
# plt.scatter(ratio21[4:], complete_task_each_explorer_HP_cost21[4:], color = '', marker = 'o', edgecolors = 'indigo', s = 150)
# plt.scatter(ratio31[4:], complete_task_each_explorer_HP_cost31[4:], color = '', marker = 'o', edgecolors = 'indigo', s = 150)
# plt.scatter(ratio41, complete_task_each_explorer_HP_cost41, color = '', marker = 'o', edgecolors = 'indigo', s = 150)

# plt.xlabel('log(Ratio(M/E))', fontsize = 15)
# plt.ylabel('Exp. Average HP Cost', fontsize = 15)
# plt.legend(['Coop. Full Info.','Coop. Linear Pred.', 'Coop. Nonlinear Pred.', 'Noncooperation', 'Incomplete Task Label'])
# plt.show()

# 25 monsters fixed
# ============================================================================================================

# plt.figure()
# plt.title('(e) SC.2 - Fixed Monsters (M=25)', fontsize = 15)
# plt.scatter(ratio12, kill_per_monster_HP_cost12, marker = 'p')
# plt.scatter(ratio22, kill_per_monster_HP_cost22, marker = '^')
# plt.scatter(ratio32, kill_per_monster_HP_cost32, marker = '*')
# plt.scatter(ratio42, kill_per_monster_HP_cost42)

# plt.scatter(ratio12[3:], kill_per_monster_HP_cost12[3:], color = '', marker = 'o', edgecolors = 'indigo', s = 150)
# plt.scatter(ratio22[3:], kill_per_monster_HP_cost22[3:], color = '', marker = 'o', edgecolors = 'indigo', s = 150)
# plt.scatter(ratio32[3:], kill_per_monster_HP_cost32[3:], color = '', marker = 'o', edgecolors = 'indigo', s = 150)
# plt.scatter(ratio42, kill_per_monster_HP_cost42, color = '', marker = 'o', edgecolors = 'indigo', s = 150)

# plt.xlabel('log(Ratio(M/E))', fontsize = 15)
# plt.ylabel('Exp. HP Cost Per Kill Monster', fontsize = 15)
# plt.legend(['Coop. Full Info.','Coop. Linear Pred.', 'Coop. Nonlinear Pred.', 'Noncooperation', 'Incomplete Task Label'])
# plt.show()

# plt.figure()
# plt.title('(f) SC.2 - Fixed Monsters (M=25)', fontsize = 15)
# plt.scatter(ratio12, kill_per_monster_number_of_explorers_losing12, marker = 'p')
# plt.scatter(ratio22, kill_per_monster_number_of_explorers_losing22, marker = '^')
# plt.scatter(ratio32, kill_per_monster_number_of_explorers_losing32, marker = '*')
# plt.scatter(ratio42, kill_per_monster_number_of_explorers_losing42)

# plt.scatter(ratio12[3:], kill_per_monster_number_of_explorers_losing12[3:], color = '', marker = 'o', edgecolors = 'indigo', s = 150)
# plt.scatter(ratio22[3:], kill_per_monster_number_of_explorers_losing22[3:], color = '', marker = 'o', edgecolors = 'indigo', s = 150)
# plt.scatter(ratio32[3:], kill_per_monster_number_of_explorers_losing32[3:], color = '', marker = 'o', edgecolors = 'indigo', s = 150)
# plt.scatter(ratio42, kill_per_monster_number_of_explorers_losing42, color = '', marker = 'o', edgecolors = 'indigo', s = 150)

# plt.xlabel('log(Ratio(M/E))', fontsize = 15)
# plt.ylabel('#Exp. Lost Per Kill Monster', fontsize = 15)
# plt.legend(['Coop. Full Info.','Coop. Linear Pred.', 'Coop. Nonlinear Pred.', 'Noncooperation', 'Incomplete Task Label'])
# plt.show()

# plt.figure()
# plt.title('(h) SC.2 - Fixed Monsters (M=25)', fontsize = 15)
# plt.scatter(ratio12, complete_task_each_explorer_energy_cost12, marker = 'p')
# plt.scatter(ratio22, complete_task_each_explorer_energy_cost22, marker = '^')
# plt.scatter(ratio32, complete_task_each_explorer_energy_cost32, marker = '*')
# plt.scatter(ratio42, complete_task_each_explorer_energy_cost42)

# plt.scatter(ratio12[3:], complete_task_each_explorer_energy_cost12[3:], color = '', marker = 'o', edgecolors = 'indigo', s = 150)
# plt.scatter(ratio22[3:], complete_task_each_explorer_energy_cost22[3:], color = '', marker = 'o', edgecolors = 'indigo', s = 150)
# plt.scatter(ratio32[3:], complete_task_each_explorer_energy_cost32[3:], color = '', marker = 'o', edgecolors = 'indigo', s = 150)
# plt.scatter(ratio42, complete_task_each_explorer_energy_cost42, color = '', marker = 'o', edgecolors = 'indigo', s = 150)

# plt.xlabel('log(Ratio(M/E))', fontsize = 15)
# plt.ylabel('Exp. Average Energy Cost', fontsize = 15)
# plt.legend(['Coop. Full Info.','Coop. Linear Pred.', 'Coop. Nonlinear Pred.', 'Noncooperation', 'Incomplete Task Label'])
# plt.show()

# plt.figure()
# plt.title('(g) SC.2 - Fixed Monsters (M=25)', fontsize = 15)
# plt.scatter(ratio12, complete_task_each_explorer_HP_cost12, marker = 'p')
# plt.scatter(ratio22, complete_task_each_explorer_HP_cost22, marker = '^')
# plt.scatter(ratio32, complete_task_each_explorer_HP_cost32, marker = '*')
# plt.scatter(ratio42, complete_task_each_explorer_HP_cost42)

# plt.scatter(ratio12[3:], complete_task_each_explorer_HP_cost12[3:], color = '', marker = 'o', edgecolors = 'indigo', s = 150)
# plt.scatter(ratio22[3:], complete_task_each_explorer_HP_cost22[3:], color = '', marker = 'o', edgecolors = 'indigo', s = 150)
# plt.scatter(ratio32[3:], complete_task_each_explorer_HP_cost32[3:], color = '', marker = 'o', edgecolors = 'indigo', s = 150)
# plt.scatter(ratio42, complete_task_each_explorer_HP_cost42, color = '', marker = 'o', edgecolors = 'indigo', s = 150)

# plt.xlabel('log(Ratio(M/E))', fontsize = 15)
# plt.ylabel('Exp. Average HP Cost', fontsize = 15)
# plt.legend(['Coop. Full Info.','Coop. Linear Pred.', 'Coop. Nonlinear Pred.', 'Noncooperation', 'Incomplete Task Label'])
# plt.show()


# ============================================================================================================
# 50 agents fixed
# ==========================================================================================================
# # Com
# X_train_1 = np.array(ratio13).reshape(-1, 1)
# Y_train_1 = np.array(kill_per_monster_HP_cost13).reshape(-1, 1)

# model = LinearRegression()
# model.fit(X_train_1, Y_train_1)
# Y_train_pred_1 = model.predict(X_train_1)


# # Incom L
# X_train_2 = np.array(ratio23).reshape(-1, 1)
# Y_train_2 = np.array(kill_per_monster_HP_cost23).reshape(-1, 1)

# model = LinearRegression()
# model.fit(X_train_2, Y_train_2)
# Y_train_pred_2 = model.predict(X_train_2)

# # Incom NonL
# X_train_3 = np.array(ratio33).reshape(-1, 1)
# Y_train_3 = np.array(kill_per_monster_HP_cost33).reshape(-1, 1)

# model = LinearRegression()
# model.fit(X_train_3, Y_train_3)
# Y_train_pred_3 = model.predict(X_train_3)


# plt.figure()
# plt.title('(i) SC.3 - Fixed Agents (E+M=50)', fontsize = 15)
# plt.scatter(ratio13, kill_per_monster_HP_cost13, marker = 'p')
# plt.scatter(ratio23, kill_per_monster_HP_cost23, marker = '^')
# plt.scatter(ratio33, kill_per_monster_HP_cost33, marker = '*')
# plt.scatter(ratio43, kill_per_monster_HP_cost43)

# plt.scatter(ratio13[6:], kill_per_monster_HP_cost13[6:], color = '', marker = 'o', edgecolors = 'indigo', s = 150)
# plt.scatter(ratio23[6:], kill_per_monster_HP_cost23[6:], color = '', marker = 'o', edgecolors = 'indigo', s = 150)
# plt.scatter(ratio33[5:], kill_per_monster_HP_cost33[5:], color = '', marker = 'o', edgecolors = 'indigo', s = 150)
# plt.scatter(ratio43[2:], kill_per_monster_HP_cost43[2:], color = '', marker = 'o', edgecolors = 'indigo', s = 150)

# plt.plot(X_train_1, Y_train_pred_1, color = 'steelblue', label = 'best line')
# plt.plot(X_train_2, Y_train_pred_2, color = 'orange', label = 'best line')
# plt.plot(X_train_3, Y_train_pred_3, color = 'green', label = 'best line')

# plt.xlabel('log(Ratio(M/E))', fontsize = 15)
# plt.ylabel('Exp. HP Cost Per Kill Monster', fontsize = 15)
# plt.legend(['Coop. Full Info.','Coop. Linear Pred.', 'Coop. Nonlinear Pred.', 'Noncooperation', 'Incomplete Task Label'])
# plt.show()

# ============================================================================================================================
# # Com
# X_train_1 = np.array(ratio13).reshape(-1, 1)
# Y_train_1 = np.array(kill_per_monster_number_of_explorers_losing13).reshape(-1, 1)

# model = LinearRegression()
# model.fit(X_train_1, Y_train_1)
# Y_train_pred_1 = model.predict(X_train_1)


# # Incom L
# X_train_2 = np.array(ratio23).reshape(-1, 1)
# Y_train_2 = np.array(kill_per_monster_number_of_explorers_losing23).reshape(-1, 1)

# model = LinearRegression()
# model.fit(X_train_2, Y_train_2)
# Y_train_pred_2 = model.predict(X_train_2)

# # Incom NonL
# X_train_3 = np.array(ratio33).reshape(-1, 1)
# Y_train_3 = np.array(kill_per_monster_number_of_explorers_losing33).reshape(-1, 1)

# model = LinearRegression()
# model.fit(X_train_3, Y_train_3)
# Y_train_pred_3 = model.predict(X_train_3)


# plt.figure()
# plt.title('(j) SC.3 - Fixed Agents (E+M=50)', fontsize = 15)
# plt.scatter(ratio13, kill_per_monster_number_of_explorers_losing13, marker = 'p')
# plt.scatter(ratio23, kill_per_monster_number_of_explorers_losing23, marker = '^')
# plt.scatter(ratio33, kill_per_monster_number_of_explorers_losing33, marker = '*')
# plt.scatter(ratio43, kill_per_monster_number_of_explorers_losing43)

# plt.scatter(ratio13[6:], kill_per_monster_number_of_explorers_losing13[6:], color = '', marker = 'o', edgecolors = 'indigo', s = 150)
# plt.scatter(ratio23[6:], kill_per_monster_number_of_explorers_losing23[6:], color = '', marker = 'o', edgecolors = 'indigo', s = 150)
# plt.scatter(ratio33[5:], kill_per_monster_number_of_explorers_losing33[5:], color = '', marker = 'o', edgecolors = 'indigo', s = 150)
# plt.scatter(ratio43[2:], kill_per_monster_number_of_explorers_losing43[2:], color = '', marker = 'o', edgecolors = 'indigo', s = 150)

# plt.plot(X_train_1, Y_train_pred_1, color = 'steelblue', label = 'best line')
# plt.plot(X_train_2, Y_train_pred_2, color = 'orange', label = 'best line')
# plt.plot(X_train_3, Y_train_pred_3, color = 'green', label = 'best line')

# plt.xlabel('log(Ratio(M/E))', fontsize = 15)
# plt.ylabel('#Exp. Lost Per Kill Monster', fontsize = 15)
# plt.legend(['Coop. Full Info.','Coop. Linear Pred.', 'Coop. Nonlinear Pred.', 'Noncooperation', 'Incomplete Task Label'])
# plt.show()

# =====================================================================================================================================
# # Com
# X_train_1 = np.array(ratio13).reshape(-1, 1)
# Y_train_1 = np.array(complete_task_each_explorer_energy_cost13).reshape(-1, 1)

# model = LinearRegression()
# model.fit(X_train_1, Y_train_1)
# Y_train_pred_1 = model.predict(X_train_1)


# # Incom L
# X_train_2 = np.array(ratio23).reshape(-1, 1)
# Y_train_2 = np.array(complete_task_each_explorer_energy_cost23).reshape(-1, 1)

# model = LinearRegression()
# model.fit(X_train_2, Y_train_2)
# Y_train_pred_2 = model.predict(X_train_2)

# # Incom NonL
# X_train_3 = np.array(ratio33).reshape(-1, 1)
# Y_train_3 = np.array(complete_task_each_explorer_energy_cost33).reshape(-1, 1)

# model = LinearRegression()
# model.fit(X_train_3, Y_train_3)
# Y_train_pred_3 = model.predict(X_train_3)


# plt.figure()
# plt.title('(l) SC.3 - Fixed Agents (E+M=50)', fontsize = 15)
# plt.scatter(ratio13, complete_task_each_explorer_energy_cost13, marker = 'p')
# plt.scatter(ratio23, complete_task_each_explorer_energy_cost23, marker = '^')
# plt.scatter(ratio33, complete_task_each_explorer_energy_cost33, marker = '*')
# plt.scatter(ratio43, complete_task_each_explorer_energy_cost43)

# plt.scatter(ratio13[6:], complete_task_each_explorer_energy_cost13[6:], color = '', marker = 'o', edgecolors = 'indigo', s = 150)
# plt.scatter(ratio23[6:], complete_task_each_explorer_energy_cost23[6:], color = '', marker = 'o', edgecolors = 'indigo', s = 150)
# plt.scatter(ratio33[5:], complete_task_each_explorer_energy_cost33[5:], color = '', marker = 'o', edgecolors = 'indigo', s = 150)
# plt.scatter(ratio43[2:], complete_task_each_explorer_energy_cost43[2:], color = '', marker = 'o', edgecolors = 'indigo', s = 150)

# plt.plot(X_train_1, Y_train_pred_1, color = 'steelblue', label = 'best line')
# plt.plot(X_train_2, Y_train_pred_2, color = 'orange', label = 'best line')
# plt.plot(X_train_3, Y_train_pred_3, color = 'green', label = 'best line')

# plt.xlabel('log(Ratio(M/E))', fontsize = 15)
# plt.ylabel('Exp. Average Energy Cost', fontsize = 15)
# plt.legend(['Coop. Full Info.','Coop. Linear Pred.', 'Coop. Nonlinear Pred.', 'Noncooperation', 'Incomplete Task Label'], loc='right', bbox_to_anchor=(1, 0.7))
# plt.show()



# ==============================================================================================================================
# # Com
# X_train_1 = np.array(ratio13).reshape(-1, 1)
# Y_train_1 = np.array(complete_task_each_explorer_HP_cost13).reshape(-1, 1)

# model = LinearRegression()
# model.fit(X_train_1, Y_train_1)
# Y_train_pred_1 = model.predict(X_train_1)


# # Incom L
# X_train_2 = np.array(ratio23).reshape(-1, 1)
# Y_train_2 = np.array(complete_task_each_explorer_HP_cost23).reshape(-1, 1)

# model = LinearRegression()
# model.fit(X_train_2, Y_train_2)
# Y_train_pred_2 = model.predict(X_train_2)

# # Polynomial Regression
# X_train_3 = np.array(ratio33).reshape(-1, 1)
# Y_train_3 = np.array(complete_task_each_explorer_HP_cost33).reshape(-1, 1)

# model = LinearRegression()
# model.fit(X_train_3, Y_train_3)
# Y_train_pred_3 = model.predict(X_train_3)


# plt.figure()
# plt.title('(k) SC.3 - All Agents', fontsize = 15)
# plt.scatter(ratio13, complete_task_each_explorer_HP_cost13, marker = 'p')
# plt.scatter(ratio23, complete_task_each_explorer_HP_cost23, marker = '^')
# plt.scatter(ratio33, complete_task_each_explorer_HP_cost33, marker = '*')
# plt.scatter(ratio43, complete_task_each_explorer_HP_cost43)

# plt.scatter(ratio13[6:], complete_task_each_explorer_HP_cost13[6:], color = '', marker = 'o', edgecolors = 'indigo', s = 150)
# plt.scatter(ratio23[6:], complete_task_each_explorer_HP_cost23[6:], color = '', marker = 'o', edgecolors = 'indigo', s = 150)
# plt.scatter(ratio33[5:], complete_task_each_explorer_HP_cost33[5:], color = '', marker = 'o', edgecolors = 'indigo', s = 150)
# plt.scatter(ratio43[2:], complete_task_each_explorer_HP_cost43[2:], color = '', marker = 'o', edgecolors = 'indigo', s = 150)

# plt.plot(X_train_1, Y_train_pred_1, color = 'steelblue', label = 'best line')
# plt.plot(X_train_2, Y_train_pred_2, color = 'orange', label = 'best line')
# plt.plot(X_train_3, Y_train_pred_3, color = 'green', label = 'best line')

# plt.xlabel('lg(Ratio(Monsters vs Explorers))', fontsize = 15)
# plt.ylabel('Exp. Average HP Cost', fontsize = 15)
# plt.legend(['Coop. Full Info.','Coop. Linear Pred.', 'Coop. Polynomial Pred.', 'Noncooperation', 'Incomplete Task Label'])
# plt.show()

# ==============================================================================================================================
# all agents
# ==============================================================================================================================
# # Com
# X_train_1 = np.array(ratio14).reshape(-1, 1)
# Y_train_1 = np.array(kill_per_monster_HP_cost14).reshape(-1, 1)

# model = LinearRegression()
# model.fit(X_train_1, Y_train_1)
# Y_train_pred_1 = model.predict(X_train_1)


# # Incom L
# X_train_2 = np.array(ratio24).reshape(-1, 1)
# Y_train_2 = np.array(kill_per_monster_HP_cost24).reshape(-1, 1)

# model = LinearRegression()
# model.fit(X_train_2, Y_train_2)
# Y_train_pred_2 = model.predict(X_train_2)

# # Incom NonL
# X_train_3 = np.array(ratio54).reshape(-1, 1)
# Y_train_3 = np.array(kill_per_monster_HP_cost54).reshape(-1, 1)

# model = LinearRegression()
# model.fit(X_train_3, Y_train_3)
# Y_train_pred_3 = model.predict(X_train_3)


# plt.figure()
# # plt.title('(i) SC.3 - Fixed Agents (E+M=50)', fontsize = 15)
# plt.scatter(ratio14, kill_per_monster_HP_cost14, marker = 'p')
# plt.scatter(ratio24, kill_per_monster_HP_cost24, marker = '^')
# plt.scatter(ratio54, kill_per_monster_HP_cost54, marker = '*')
# plt.scatter(ratio44, kill_per_monster_HP_cost44)

# # plt.scatter(ratio14[10:12], kill_per_monster_HP_cost14[10:12], color = '', marker = 'o', edgecolors = 'indigo', s = 150)
# # plt.scatter(ratio14[13:], kill_per_monster_HP_cost14[13:], color = '', marker = 'o', edgecolors = 'indigo', s = 150)
# # plt.scatter(ratio24[10:12], kill_per_monster_HP_cost24[10:12], color = '', marker = 'o', edgecolors = 'indigo', s = 150)
# # plt.scatter(ratio24[13:], kill_per_monster_HP_cost24[13:], color = '', marker = 'o', edgecolors = 'indigo', s = 150)
# # plt.scatter(ratio54[9:], kill_per_monster_HP_cost54[9:], color = '', marker = 'o', edgecolors = 'indigo', s = 150)
# # plt.scatter(ratio44[2:], kill_per_monster_HP_cost44[2:], color = '', marker = 'o', edgecolors = 'indigo', s = 150)

# plt.plot(X_train_1, Y_train_pred_1, color = 'steelblue', label = 'best line')
# plt.plot(X_train_2, Y_train_pred_2, color = 'orange', label = 'best line')
# plt.plot(X_train_3, Y_train_pred_3, color = 'green', label = 'best line')

# plt.xlabel('log(Ratio(M/E))', fontsize = 15)
# plt.ylabel('Exp. HP Cost Per Kill Monster', fontsize = 15)
# plt.legend(['Coop. Full Info. Trend','Coop. Linear Pred. Trend', 'Coop. Polynomial Pred. Trend', 'Coop. Full Info.','Coop. Linear Pred.', 'Coop. Polynomial Pred.', 'Noncooperation', 'Incomplete Task Label'])
# plt.show()

# ============================================================================================================================
# # Com
# X_train_1 = np.array(ratio14).reshape(-1, 1)
# Y_train_1 = np.array(kill_per_monster_number_of_explorers_losing14).reshape(-1, 1)

# model = LinearRegression()
# model.fit(X_train_1, Y_train_1)
# Y_train_pred_1 = model.predict(X_train_1)


# # Incom L
# X_train_2 = np.array(ratio24).reshape(-1, 1)
# Y_train_2 = np.array(kill_per_monster_number_of_explorers_losing24).reshape(-1, 1)

# model = LinearRegression()
# model.fit(X_train_2, Y_train_2)
# Y_train_pred_2 = model.predict(X_train_2)

# # Incom NonL
# X_train_3 = np.array(ratio54).reshape(-1, 1)
# Y_train_3 = np.array(kill_per_monster_number_of_explorers_losing54).reshape(-1, 1)

# model = LinearRegression()
# model.fit(X_train_3, Y_train_3)
# Y_train_pred_3 = model.predict(X_train_3)


# plt.figure()
# # plt.title('(j) SC.3 - Fixed Agents (E+M=50)', fontsize = 15)
# plt.scatter(ratio14, kill_per_monster_number_of_explorers_losing14, marker = 'p')
# plt.scatter(ratio24, kill_per_monster_number_of_explorers_losing24, marker = '^')
# plt.scatter(ratio54, kill_per_monster_number_of_explorers_losing54, marker = '*')
# plt.scatter(ratio44, kill_per_monster_number_of_explorers_losing44)

# # plt.scatter(ratio14[10:12], kill_per_monster_number_of_explorers_losing14[10:12], color = '', marker = 'o', edgecolors = 'indigo', s = 150)
# # plt.scatter(ratio14[13:], kill_per_monster_number_of_explorers_losing14[13:], color = '', marker = 'o', edgecolors = 'indigo', s = 150)
# # plt.scatter(ratio24[10:12], kill_per_monster_number_of_explorers_losing24[10:12], color = '', marker = 'o', edgecolors = 'indigo', s = 150)
# # plt.scatter(ratio24[13:], kill_per_monster_number_of_explorers_losing24[13:], color = '', marker = 'o', edgecolors = 'indigo', s = 150)
# # plt.scatter(ratio54[9:], kill_per_monster_number_of_explorers_losing54[9:], color = '', marker = 'o', edgecolors = 'indigo', s = 150)
# # plt.scatter(ratio44[2:], kill_per_monster_number_of_explorers_losing44[2:], color = '', marker = 'o', edgecolors = 'indigo', s = 150)

# plt.plot(X_train_1, Y_train_pred_1, color = 'steelblue', label = 'best line')
# plt.plot(X_train_2, Y_train_pred_2, color = 'orange', label = 'best line')
# plt.plot(X_train_3, Y_train_pred_3, color = 'green', label = 'best line')

# plt.xlabel('log(Ratio(M/E))', fontsize = 15)
# plt.ylabel('#Exp. Lost Per Kill Monster', fontsize = 15)
# plt.legend(['Coop. Full Info. Trend','Coop. Linear Pred. Trend', 'Coop. Polynomial Pred. Trend', 'Coop. Full Info.','Coop. Linear Pred.', 'Coop. Polynomial Pred.', 'Noncooperation', 'Incomplete Task Label'])
# plt.show()

# =====================================================================================================================================
# # Com
# X_train_1 = np.array(ratio14).reshape(-1, 1)
# Y_train_1 = np.array(complete_task_each_explorer_energy_cost14).reshape(-1, 1)

# model = LinearRegression()
# model.fit(X_train_1, Y_train_1)
# Y_train_pred_1 = model.predict(X_train_1)


# # Incom L
# X_train_2 = np.array(ratio24).reshape(-1, 1)
# Y_train_2 = np.array(complete_task_each_explorer_energy_cost24).reshape(-1, 1)

# model = LinearRegression()
# model.fit(X_train_2, Y_train_2)
# Y_train_pred_2 = model.predict(X_train_2)

# # Incom NonL
# X_train_3 = np.array(ratio54).reshape(-1, 1)
# Y_train_3 = np.array(complete_task_each_explorer_energy_cost54).reshape(-1, 1)

# model = LinearRegression()
# model.fit(X_train_3, Y_train_3)
# Y_train_pred_3 = model.predict(X_train_3)


# plt.figure()
# # plt.title('(l) SC.3 - Fixed Agents (E+M=50)', fontsize = 15)
# plt.scatter(ratio14, complete_task_each_explorer_energy_cost14, marker = 'p')
# plt.scatter(ratio24, complete_task_each_explorer_energy_cost24, marker = '^')
# plt.scatter(ratio54, complete_task_each_explorer_energy_cost54, marker = '*')
# plt.scatter(ratio44, complete_task_each_explorer_energy_cost44)

# plt.scatter(ratio14[10:12], complete_task_each_explorer_energy_cost14[10:12], color = '', marker = 'o', edgecolors = 'indigo', s = 150)
# plt.scatter(ratio14[13:], complete_task_each_explorer_energy_cost14[13:], color = '', marker = 'o', edgecolors = 'indigo', s = 150)
# plt.scatter(ratio24[10:12], complete_task_each_explorer_energy_cost24[10:12], color = '', marker = 'o', edgecolors = 'indigo', s = 150)
# plt.scatter(ratio24[13:], complete_task_each_explorer_energy_cost24[13:], color = '', marker = 'o', edgecolors = 'indigo', s = 150)
# plt.scatter(ratio54[9:], complete_task_each_explorer_energy_cost54[9:], color = '', marker = 'o', edgecolors = 'indigo', s = 150)
# plt.scatter(ratio44[2:], complete_task_each_explorer_energy_cost44[2:], color = '', marker = 'o', edgecolors = 'indigo', s = 150)

# plt.plot(X_train_1, Y_train_pred_1, color = 'steelblue', label = 'best line')
# plt.plot(X_train_2, Y_train_pred_2, color = 'orange', label = 'best line')
# plt.plot(X_train_3, Y_train_pred_3, color = 'green', label = 'best line')

# plt.xlabel('log(Ratio(M/E))', fontsize = 15)
# plt.ylabel('Exp. Average Energy Cost', fontsize = 15)
# plt.legend(['Coop. Full Info. Trend','Coop. Linear Pred. Trend', 'Coop. Polynomial Pred. Trend', 'Coop. Full Info.','Coop. Linear Pred.', 'Coop. Polynomial Pred.', 'Noncooperation', 'Incomplete Task Label'], loc='right', bbox_to_anchor=(1, 0.7))
# plt.show()

# ================================================================================================================
# Com
X_train_1 = np.array(ratio14).reshape(-1, 1)
Y_train_1 = np.array(complete_task_each_explorer_HP_cost14).reshape(-1, 1)

model = LinearRegression()
model.fit(X_train_1, Y_train_1)
Y_train_pred_1 = model.predict(X_train_1)


# Incom L
X_train_2 = np.array(ratio24).reshape(-1, 1)
Y_train_2 = np.array(complete_task_each_explorer_HP_cost24).reshape(-1, 1)

model = LinearRegression()
model.fit(X_train_2, Y_train_2)
Y_train_pred_2 = model.predict(X_train_2)

# Polynomial Regression
X_train_3 = np.array(ratio54).reshape(-1, 1)
Y_train_3 = np.array(complete_task_each_explorer_HP_cost54).reshape(-1, 1)

model = LinearRegression()
model.fit(X_train_3, Y_train_3)
Y_train_pred_3 = model.predict(X_train_3)


plt.figure()
# plt.title('(k) SC.3 - All Agents', fontsize = 15)
plt.scatter(ratio14, complete_task_each_explorer_HP_cost14, marker = 'p')
plt.scatter(ratio24, complete_task_each_explorer_HP_cost24, marker = '^')
plt.scatter(ratio54, complete_task_each_explorer_HP_cost54, marker = '*')
plt.scatter(ratio44, complete_task_each_explorer_HP_cost44)

# plt.scatter(ratio14[10:12], complete_task_each_explorer_HP_cost14[10:12], color = '', marker = 'o', edgecolors = 'indigo', s = 150)
# plt.scatter(ratio14[13:], complete_task_each_explorer_HP_cost14[13:], color = '', marker = 'o', edgecolors = 'indigo', s = 150)
# plt.scatter(ratio24[10:12], complete_task_each_explorer_HP_cost24[10:12], color = '', marker = 'o', edgecolors = 'indigo', s = 150)
# plt.scatter(ratio24[13:], complete_task_each_explorer_HP_cost24[13:], color = '', marker = 'o', edgecolors = 'indigo', s = 150)
# plt.scatter(ratio54[9:], complete_task_each_explorer_HP_cost54[9:], color = '', marker = 'o', edgecolors = 'indigo', s = 150)
# plt.scatter(ratio44[2:], complete_task_each_explorer_HP_cost44[2:], color = '', marker = 'o', edgecolors = 'indigo', s = 150)

plt.plot(X_train_1, Y_train_pred_1, color = 'steelblue')
plt.plot(X_train_2, Y_train_pred_2, color = 'orange')
plt.plot(X_train_3, Y_train_pred_3, color = 'green')

plt.xlabel('lg(Ratio(Monsters vs Explorers))', fontsize = 15)
plt.ylabel('Exp. Average HP Cost', fontsize = 15)
plt.legend(['Coop. Full Info. Trend','Coop. Linear Pred. Trend', 'Coop. Polynomial Pred. Trend', 'Coop. Full Info.','Coop. Linear Pred.', 'Coop. Polynomial Pred.', 'Noncooperation', 'Incomplete Task Label'])
plt.show()
